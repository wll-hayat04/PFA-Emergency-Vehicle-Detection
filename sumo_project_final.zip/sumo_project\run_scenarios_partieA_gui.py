import os
import argparse
import time
import traci

# =============================================================
# CONFIGURATION
# =============================================================

SUMO_HOME = r"C:\Program Files (x86)\Eclipse\Sumo"
os.environ["SUMO_HOME"] = SUMO_HOME

SUMO_BINARY = rf"{SUMO_HOME}\bin\sumo-gui.exe"
SUMO_CFG = r"C:\Users\user\Desktop\sumo_project\simulation_intersection.sumocfg"

ROUTES = {
    "faible": r"C:\Users\user\Desktop\sumo_project\routes_faible.rou.xml",
    "moyen": r"C:\Users\user\Desktop\sumo_project\routes_moyen.rou.xml",
    "dense": r"C:\Users\user\Desktop\sumo_project\routes_dense.rou.xml",
}

AMBULANCE_ID = "ambulance0"
AMBULANCE_DEPART_STEP = 10
SIMULATION_END = 220

# Route ambulance — Partie A : sud -> intersection -> nord
AMBULANCE_ROUTE = [
    "south_entry",
    "south_to_center",
    "center_to_north",
    "north_exit"
]

YOLO_CONFIDENCE = 0.71


# =============================================================
# OUTILS TRAFFIC LIGHT
# =============================================================

def get_ambulance_link_indices(tls_id, amb_edge, next_edge):
    """
    Trouve les liens du feu correspondant à la trajectoire de l'ambulance.
    """
    controlled_links = traci.trafficlight.getControlledLinks(tls_id)
    indices = []

    for i, phase_links in enumerate(controlled_links):
        for link in phase_links:
            if not link:
                continue

            try:
                from_edge = traci.lane.getEdgeID(link[0])
                to_edge = traci.lane.getEdgeID(link[1])
            except Exception:
                continue

            if from_edge == amb_edge and (next_edge is None or to_edge == next_edge):
                indices.append(i)

    return indices


def force_green_for_ev(tls_id, amb_indices):
    """
    Force au vert uniquement les liens utilisés par l'ambulance.
    Les autres mouvements verts sont mis au rouge.
    """
    state = list(traci.trafficlight.getRedYellowGreenState(tls_id))
    new_state = []

    for idx, sig in enumerate(state):
        if idx in amb_indices:
            new_state.append("G")
        elif sig in ("g", "G"):
            new_state.append("r")
        else:
            new_state.append(sig)

    traci.trafficlight.setRedYellowGreenState(tls_id, "".join(new_state))


def add_ambulance():
    """
    Ajoute l'ambulance dans la simulation.
    """
    try:
        traci.route.add("ambulance_route_gui", AMBULANCE_ROUTE)

        traci.vehicle.add(
            vehID=AMBULANCE_ID,
            routeID="ambulance_route_gui",
            depart="now",
            typeID="DEFAULT_VEHTYPE"
        )

        # Rouge pour bien la distinguer dans SUMO-GUI
        traci.vehicle.setColor(AMBULANCE_ID, (255, 0, 0, 255))
        traci.vehicle.setMaxSpeed(AMBULANCE_ID, 25.0)

        print(">>> Ambulance ajoutée à t=10")
        return True

    except Exception as e:
        print(f"[ERREUR] Ambulance non ajoutée : {e}")
        return False


# =============================================================
# SIMULATION GUI
# =============================================================

def run_gui(mode="baseline", threshold=0.70, traffic="moyen", seed=42, delay=120):
    """
    Lance SUMO-GUI pour visualiser un seul mode.
    mode : baseline | auto | confidence
    threshold : seuil utilisé uniquement pour confidence
    traffic : faible | moyen | dense
    """

    if traffic not in ROUTES:
        raise ValueError("traffic doit être : faible, moyen ou dense")

    route_file = ROUTES[traffic]

    sumo_cmd = [
        SUMO_BINARY,
        "-c", SUMO_CFG,
        "--route-files", route_file,
        "--seed", str(seed),
        "--delay", str(delay),
        "--start",
        "--quit-on-end",
        "--no-warnings"
    ]

    print("\n" + "=" * 70)
    print("VISUALISATION SUMO-GUI — PARTIE A")
    print("=" * 70)
    print(f"Mode              : {mode}")
    print(f"Trafic            : {traffic}")
    print(f"Seed              : {seed}")
    print(f"YOLO confidence   : {YOLO_CONFIDENCE}")
    print(f"Threshold θ       : {threshold}")
    print(f"Route ambulance   : {' -> '.join(AMBULANCE_ROUTE)}")
    print("=" * 70 + "\n")

    traci.start(sumo_cmd)

    tls_ids = traci.trafficlight.getIDList()
    original_programs = {
        tls_id: traci.trafficlight.getProgram(tls_id)
        for tls_id in tls_ids
    }

    ambulance_added = False
    ev_start = None
    ev_end = None
    tls_forced = set()

    step = 0

    while step < SIMULATION_END:
        traci.simulationStep()
        vehicles = traci.vehicle.getIDList()

        # Ajout de l'ambulance
        if step == AMBULANCE_DEPART_STEP and not ambulance_added:
            ambulance_added = add_ambulance()
            ev_start = step

        vehicles = traci.vehicle.getIDList()

        # Gestion de la priorité
        if AMBULANCE_ID in vehicles:
            route = traci.vehicle.getRoute(AMBULANCE_ID)
            route_index = traci.vehicle.getRouteIndex(AMBULANCE_ID)
            route_len = len(route)

            amb_edge = traci.vehicle.getRoadID(AMBULANCE_ID)
            next_edge = route[route_index + 1] if route_index + 1 < route_len else None

            # Décision selon le mode
            if mode == "baseline":
                priority_active = False
                status = "NO PRIORITY"

            elif mode == "auto":
                priority_active = True
                status = "AUTO PRIORITY"

            elif mode == "confidence":
                priority_active = YOLO_CONFIDENCE >= threshold
                if priority_active:
                    status = f"CONF ACCEPTED ({YOLO_CONFIDENCE:.2f} >= {threshold:.2f})"
                else:
                    status = f"CONF REJECTED ({YOLO_CONFIDENCE:.2f} < {threshold:.2f})"

            else:
                raise ValueError("mode doit être : baseline, auto ou confidence")

            # Appliquer la priorité si nécessaire
            for tls_id in tls_ids:
                amb_indices = get_ambulance_link_indices(tls_id, amb_edge, next_edge)

                if amb_indices and priority_active:
                    force_green_for_ev(tls_id, amb_indices)
                    tls_forced.add(tls_id)

                elif tls_id in tls_forced and not amb_indices:
                    traci.trafficlight.setProgram(tls_id, original_programs[tls_id])
                    tls_forced.discard(tls_id)

            # Affichage console
            wait = traci.vehicle.getAccumulatedWaitingTime(AMBULANCE_ID)
            speed = traci.vehicle.getSpeed(AMBULANCE_ID)

            print(
                f"t={step:03d} | edge={amb_edge:18s} | "
                f"wait={wait:5.1f}s | speed={speed:5.1f} | {status}"
            )

        else:
            if ambulance_added and ev_end is None and step > AMBULANCE_DEPART_STEP:
                ev_end = step
                print(f"\n>>> Ambulance arrivée à t={step}")

            # Restaurer les feux
            for tls_id in list(tls_forced):
                traci.trafficlight.setProgram(tls_id, original_programs[tls_id])
                tls_forced.discard(tls_id)

        step += 1

    # KPIs finaux
    if ev_start is not None and ev_end is not None:
        ev_travel_time = ev_end - ev_start
    else:
        ev_travel_time = None

    print("\n" + "=" * 70)
    print("RÉSUMÉ VISUEL")
    print("=" * 70)
    print(f"Mode              : {mode}")
    print(f"Traffic           : {traffic}")
    print(f"EV travel time    : {ev_travel_time} steps")
    print("=" * 70)

    traci.close(wait=False)


# =============================================================
# MAIN
# =============================================================

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Visualisation SUMO-GUI des 3 modes de préemption — Partie A"
    )

    parser.add_argument(
        "--mode",
        choices=["baseline", "auto", "confidence"],
        default="baseline",
        help="Mode à visualiser"
    )

    parser.add_argument(
        "--threshold",
        type=float,
        default=0.70,
        help="Seuil θ pour le mode confidence"
    )

    parser.add_argument(
        "--traffic",
        choices=["faible", "moyen", "dense"],
        default="moyen",
        help="Niveau de trafic"
    )

    parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Seed de simulation"
    )

    parser.add_argument(
        "--delay",
        type=int,
        default=120,
        help="Délai SUMO-GUI en ms"
    )

    args = parser.parse_args()

    run_gui(
        mode=args.mode,
        threshold=args.threshold,
        traffic=args.traffic,
        seed=args.seed,
        delay=args.delay
    )