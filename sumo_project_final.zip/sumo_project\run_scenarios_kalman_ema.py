"""
=============================================================
  PFA – Simulation SUMO avec Filtre de Kalman
  Réseau étendu : 2 intersections avec feux (center + center2)
  Route ambulance : south → center1 → center2 → east2

  Comparaison :
    - baseline   : aucune priorité
    - confidence : YOLO bruitée sans filtre
    - kalman     : YOLO bruitée lissée par Kalman
    - ema        : YOLO bruitée lissée par moyenne exponentielle
=============================================================
"""

import os
import csv
import random
import traci
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np

# =========================
# CHEMINS
# =========================
SUMO_HOME = r"C:\Program Files (x86)\Eclipse\Sumo"
os.environ["SUMO_HOME"] = SUMO_HOME
SUMO_CFG  = r"C:\Users\user\Desktop\sumo_project\simulation_intersection.sumocfg"
os.makedirs("figures", exist_ok=True)

# =========================
# PARAMÈTRES
# =========================
AMBULANCE_ID          = "ambulance0"
AMBULANCE_DEPART_STEP = 10
SIMULATION_END        = 200

# Route ambulance traversant les 2 intersections
AMBULANCE_ROUTE = (
    "south_entry",
    "south_to_center",
    "center_to_center2",
    "mid_to_center2",
    "center2_to_east2",
)

TRUE_YOLO_CONFIDENCE = 0.71
THRESHOLD            = 0.65
MISS_PROBABILITY     = 0.35
YOLO_NOISE_STD       = 0.12

SCENARIOS = [
    {"mode": "baseline",    "label": "Baseline (sans priorité)"},
    {"mode": "confidence",  "label": f"Confidence brute θ={THRESHOLD}"},
    {"mode": "kalman",      "label": f"Kalman θ={THRESHOLD}"},
    {"mode": "ema",         "label": f"EMA θ={THRESHOLD}"},
]


# =========================
# FILTRE DE KALMAN 1D
# =========================
class KalmanFilter1D:
    def __init__(self, initial_x=0.5, P=1.0, Q=0.005, R=0.04):
        self.x = initial_x
        self.P = P
        self.Q = Q
        self.R = R

    def predict(self):
        """Prédiction seule — sans correction (utilisé pour les faux négatifs)"""
        self.P = self.P + self.Q
        return self.x

    def step(self, measurement):
        """Prédiction + correction"""
        self.predict()
        K      = self.P / (self.P + self.R)
        self.x = self.x + K * (measurement - self.x)
        self.P = (1 - K) * self.P
        return self.x


# =========================
# LISSAGE EXPONENTIEL (EMA)
# =========================
class EMAFilter:
    """
    Filtre de lissage exponentiel appliqué au score de confiance YOLO.
    alpha proche de 1 : filtre plus réactif.
    alpha proche de 0 : filtre plus lisse.
    """
    def __init__(self, alpha=0.30, initial_value=None):
        self.alpha = alpha
        self.value = initial_value

    def step(self, measurement):
        if self.value is None:
            self.value = measurement
        else:
            self.value = self.alpha * measurement + (1 - self.alpha) * self.value
        return self.value

    def predict(self):
        # En cas de faux négatif, on conserve la dernière estimation.
        return self.value if self.value is not None else 0.0

# =========================
# SIMULATION YOLO BRUITÉE
# =========================
def simulate_yolo(true_conf, miss_prob, noise_std, rng):
    if rng.random() < miss_prob:
        return 0.0
    return max(0.0, min(1.0, true_conf + rng.gauss(0, noise_std)))


# =========================
# INDICES LIENS AMBULANCE
# =========================
def get_ambulance_link_indices(tls_id, amb_edge, next_edge):
    controlled = traci.trafficlight.getControlledLinks(tls_id)
    indices = []
    for i, phase_links in enumerate(controlled):
        for link in phase_links:
            if not link:
                continue
            try:
                from_edge = traci.lane.getEdgeID(link[0])
                to_edge   = traci.lane.getEdgeID(link[1])
            except Exception:
                continue
            if from_edge == amb_edge and (next_edge is None or to_edge == next_edge):
                indices.append(i)
    return indices


# =========================
# FORCER FEU VERT
# =========================
def force_green_for_ambulance(tls_id, amb_indices):
    state     = list(traci.trafficlight.getRedYellowGreenState(tls_id))
    new_state = []
    for idx, sig in enumerate(state):
        if idx in amb_indices:
            new_state.append("G")
        elif sig in ("g", "G"):
            new_state.append("r")
        else:
            new_state.append(sig)
    traci.trafficlight.setRedYellowGreenState(tls_id, "".join(new_state))


# =========================
# SIMULATION PRINCIPALE
# =========================
def run_simulation(mode, seed=42):
    rng = random.Random(seed)

    sumo_cmd = [
        rf"{SUMO_HOME}\bin\sumo-gui.exe",
        "-c", SUMO_CFG,
        "--delay", "100",
        "--ignore-route-errors",
        "--no-warnings"
    ]
    traci.start(sumo_cmd)

    step                 = 0
    ambulance_added      = False
    ev_travel_start      = None
    ev_travel_end        = None
    ev_waiting_time      = 0
    ev_max_route_index   = -1
    normal_wait_sum      = 0
    normal_vehicle_count = 0
    queue_sum            = 0
    steps_count          = 0

    tls_ids = traci.trafficlight.getIDList()
    print(f"  Feux détectés : {tls_ids}")

    original_programs = {}
    for tls_id in tls_ids:
        original_programs[tls_id] = traci.trafficlight.getProgram(tls_id)

    tls_forced = set()
    kalman = KalmanFilter1D(
        initial_x = TRUE_YOLO_CONFIDENCE,
        P = 0.05,
        Q = 0.001,
        R = 0.03,
    )
    ema = EMAFilter(alpha=0.30, initial_value=TRUE_YOLO_CONFIDENCE)

    series = {
        "steps": [], "raw": [], "filtered": [],
        "priority": [], "tls_active": []
    }

    while step < SIMULATION_END:
        traci.simulationStep()
        vehicles = traci.vehicle.getIDList()

        # ── Ajout ambulance ──────────────────────────────────
        if step == AMBULANCE_DEPART_STEP and not ambulance_added:
            try:
                traci.route.add("ambulance_route", AMBULANCE_ROUTE)
                traci.vehicle.add(AMBULANCE_ID, "ambulance_route", depart="now")
                traci.vehicle.setColor(AMBULANCE_ID, (255, 0, 0, 255))
                traci.vehicle.setMaxSpeed(AMBULANCE_ID, 25)
                ambulance_added = True
                ev_travel_start = step
                print(f"  >>> Ambulance ajoutée à t={step}")
            except Exception as e:
                print(f"  ⚠️ Erreur : {e}")

        vehicles = traci.vehicle.getIDList()

        # ── Gestion priorité ─────────────────────────────────
        if AMBULANCE_ID in vehicles:
            ev_waiting_time    = traci.vehicle.getAccumulatedWaitingTime(AMBULANCE_ID)
            route_index        = traci.vehicle.getRouteIndex(AMBULANCE_ID)
            ev_max_route_index = max(ev_max_route_index, route_index)
            route              = traci.vehicle.getRoute(AMBULANCE_ID)
            route_len          = len(route)

            if route_len > 0 and route_index >= route_len - 1 and ev_travel_end is None:
                ev_travel_end = step
                print(f"  >>> Ambulance arrivée à t={step}")

            amb_edge  = traci.vehicle.getRoadID(AMBULANCE_ID)
            next_edge = route[route_index + 1] if route_index + 1 < route_len else None

            # ── Calcul confiance ─────────────────────────────
            if mode in ("confidence", "kalman", "ema"):
                raw_conf = simulate_yolo(TRUE_YOLO_CONFIDENCE,
                                         MISS_PROBABILITY, YOLO_NOISE_STD, rng)

                if mode == "confidence":
                    effective_conf = raw_conf

                elif mode == "kalman":
                    # Faux négatif détecté (0.0) → prédiction seule, pas de correction.
                    # Kalman maintient son estimation sans être tiré vers le bas.
                    if raw_conf == 0.0:
                        kalman.predict()
                        effective_conf = kalman.x
                    else:
                        effective_conf = kalman.step(raw_conf)

                elif mode == "ema":
                    # En cas de faux négatif, EMA conserve la dernière estimation.
                    if raw_conf == 0.0:
                        effective_conf = ema.predict()
                    else:
                        effective_conf = ema.step(raw_conf)

            else:
                raw_conf       = 0.0
                effective_conf = 0.0

            # Enregistrer série
            if mode in ("confidence", "kalman", "ema"):
                series["steps"].append(step)
                series["raw"].append(raw_conf)
                series["filtered"].append(effective_conf)
                series["priority"].append(1.0 if effective_conf >= THRESHOLD else 0.0)
                series["tls_active"].append(amb_edge)

            # ── Application priorité feux ────────────────────
            if mode in ("confidence", "kalman", "ema"):
                priority_active = effective_conf >= THRESHOLD

                for tls_id in tls_ids:
                    amb_indices = get_ambulance_link_indices(tls_id, amb_edge, next_edge)

                    if amb_indices and priority_active:
                        force_green_for_ambulance(tls_id, amb_indices)
                        tls_forced.add(tls_id)
                    elif tls_id in tls_forced and not amb_indices:
                        traci.trafficlight.setProgram(tls_id, original_programs[tls_id])
                        tls_forced.discard(tls_id)

        else:
            for tls_id in list(tls_forced):
                traci.trafficlight.setProgram(tls_id, original_programs[tls_id])
                tls_forced.discard(tls_id)

        # ── Sortie réseau ────────────────────────────────────
        if (ambulance_added and AMBULANCE_ID not in vehicles
                and ev_travel_end is None and step > AMBULANCE_DEPART_STEP):
            ev_travel_end = step
            print(f"  >>> Ambulance sortie du réseau à t={step}")

        # ── Métriques trafic normal ──────────────────────────
        queue_count = 0
        for veh in vehicles:
            if veh != AMBULANCE_ID:
                normal_wait_sum      += traci.vehicle.getAccumulatedWaitingTime(veh)
                normal_vehicle_count += 1
                if traci.vehicle.getSpeed(veh) < 0.1:
                    queue_count += 1

        queue_sum   += queue_count
        steps_count += 1
        step        += 1

    traci.close(wait=False)

    ev_travel_time   = (ev_travel_end - ev_travel_start
                        if ev_travel_start and ev_travel_end else None)
    avg_normal_delay = round(normal_wait_sum / normal_vehicle_count, 2) if normal_vehicle_count > 0 else 0
    avg_queue_length = round(queue_sum / steps_count, 2)                if steps_count > 0          else 0

    extra = {}
    if series["raw"]:
        raw      = series["raw"]
        filtered = series["filtered"]
        missed   = sum(1 for v in raw if v == 0.0)
        coupures_evitees = sum(
            1 for r, f in zip(raw, filtered)
            if r < THRESHOLD and f >= THRESHOLD
        )
        extra = {
            "nb_detections"       : len(raw),
            "nb_faux_negatifs"    : missed,
            "nb_coupures_evitees" : coupures_evitees,
            "conf_raw_mean"       : round(float(np.mean(raw)), 4),
            "conf_filtered_mean"  : round(float(np.mean(filtered)), 4),
            "conf_raw_std"        : round(float(np.std(raw)), 4),
            "conf_filtered_std"   : round(float(np.std(filtered)), 4),
            "priority_active_pct" : round(100 * sum(series["priority"]) / max(len(series["priority"]), 1), 1),
        }

    return {
        "metrics": {
            "mode"              : mode,
            "threshold"         : THRESHOLD,
            "ev_travel_time"    : ev_travel_time,
            "ev_waiting_time"   : round(ev_waiting_time, 2),
            "ev_max_route_index": ev_max_route_index,
            "avg_normal_delay"  : avg_normal_delay,
            "avg_queue_length"  : avg_queue_length,
            **extra,
        },
        "series": series,
    }


# =========================
# GRAPHIQUES
# =========================
COLORS = {
    "baseline"  : "#e74c3c",
    "confidence": "#e67e22",
    "kalman"    : "#2ecc71",
    "ema"       : "#3498db",
}

def fig1_series_comparison(conf_series, kalman_series, ema_series):
    series_list = [
        ("Confidence brute", conf_series, "#e67e22"),
        ("Kalman",           kalman_series, "#2ecc71"),
        ("EMA",              ema_series, "#3498db"),
    ]

    fig, axes = plt.subplots(3, 2, figsize=(15, 10),
                              gridspec_kw={"width_ratios": [3, 1]})
    fig.suptitle("Comparaison des filtres appliqués au score YOLO — Réseau 2 Intersections",
                 fontsize=14, fontweight="bold")

    for row, (label, series, color) in enumerate(series_list):
        ax_curve = axes[row][0]
        ax_prio  = axes[row][1]

        steps    = series.get("steps", [])
        raw      = series.get("raw", [])
        filtered = series.get("filtered", [])
        priority = series.get("priority", [])

        ax_curve.plot(steps, raw, color="#e67e22", linewidth=1.0,
                      alpha=0.45, label="Score YOLO brut")

        if label == "Confidence brute":
            ax_curve.plot(steps, raw, color=color, linewidth=2.0,
                          label="Score utilisé")
        else:
            ax_curve.plot(steps, filtered, color=color, linewidth=2.4,
                          label=f"Score filtré {label}")

        ax_curve.axhline(THRESHOLD, color="#e74c3c", linestyle="--",
                         linewidth=1.4, label=f"Seuil θ={THRESHOLD}")
        for st, r in zip(steps, raw):
            if r == 0.0:
                ax_curve.axvspan(st - 0.5, st + 0.5, color="#e74c3c", alpha=0.10)

        ax_curve.set_title(label, fontweight="bold")
        ax_curve.set_ylim(-0.05, 1.15)
        ax_curve.set_ylabel("Confiance")
        ax_curve.grid(alpha=0.3, linestyle="--")
        ax_curve.legend(fontsize=8, loc="lower right")

        ax_prio.fill_between(steps, priority, step="post", color=color, alpha=0.65)
        ax_prio.set_ylim(-0.1, 1.2)
        ax_prio.set_yticks([0, 1])
        ax_prio.set_yticklabels(["OFF", "ON"])
        ax_prio.set_title("Priorité", fontweight="bold")
        ax_prio.grid(alpha=0.3, linestyle="--")

        changes = sum(abs(priority[i] - priority[i-1]) for i in range(1, len(priority)))
        pct = round(100 * sum(priority) / max(len(priority), 1), 1)
        ax_prio.set_xlabel(f"{pct}% actif — {int(changes)} changements")

    plt.tight_layout()
    path = "figures/kalman_ema_fig1_series_comparison.png"
    plt.savefig(path, bbox_inches="tight")
    plt.close()
    print(f"✅ Figure 1 exportée : {path}")

def fig2_kpi_comparison(all_metrics):
    modes  = [r["mode"] for r in all_metrics]
    labels = {
        "baseline"  : "Baseline\n(sans priorité)",
        "confidence": f"Confidence brute\nθ={THRESHOLD}",
        "kalman"    : f"Kalman\nθ={THRESHOLD}",
        "ema"       : f"EMA\nθ={THRESHOLD}",
    }
    colors = [COLORS[m] for m in modes]

    metrics_list = [
        ("ev_travel_time",   "Temps de parcours EV (steps)"),
        ("ev_waiting_time",  "Temps d'attente EV (s)"),
        ("avg_normal_delay", "Délai moyen trafic civil (s)"),
        ("avg_queue_length", "File d'attente moyenne (véh)"),
    ]

    fig, axes = plt.subplots(2, 2, figsize=(13, 9))
    fig.suptitle("Comparaison Baseline vs Confidence vs Kalman vs EMA — Réseau 2 Intersections",
                 fontsize=14, fontweight="bold", y=1.01)

    for ax, (metric, title) in zip(axes.flat, metrics_list):
        values = [r.get(metric) or 0 for r in all_metrics]
        x      = np.arange(len(modes))
        bars   = ax.bar(x, values, 0.5, color=colors, alpha=0.88,
                        edgecolor="white", linewidth=0.8)

        for bar, val in zip(bars, values):
            if val > 0:
                ax.text(bar.get_x() + bar.get_width() / 2,
                        bar.get_height() + max(values) * 0.02,
                        f"{val:.1f}", ha="center", va="bottom",
                        fontsize=10, fontweight="bold")

        ax.set_title(title, fontweight="bold", pad=8)
        ax.set_xticks(x)
        ax.set_xticklabels([labels.get(m, m) for m in modes], fontsize=10)
        ax.set_ylim(bottom=0, top=max(values) * 1.2 if max(values) > 0 else 1)
        ax.grid(axis="y", alpha=0.3, linestyle="--")

    handles = [mpatches.Patch(color=COLORS[m],
               label=labels.get(m, m).replace("\n", " ")) for m in modes]
    fig.legend(handles=handles, loc="lower center", ncol=4,
               bbox_to_anchor=(0.5, -0.03), fontsize=10)

    plt.tight_layout()
    path = "figures/kalman_ema_fig2_kpis.png"
    plt.savefig(path, bbox_inches="tight")
    plt.close()
    print(f"✅ Figure 2 exportée : {path}")


def fig3_robustesse(conf_series, kalman_series, ema_series):
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    fig.suptitle("Robustesse des filtres — Kalman vs EMA",
                 fontsize=14, fontweight="bold")

    series_list = [
        ("Confidence brute", conf_series, "#e67e22"),
        ("Kalman",           kalman_series, "#2ecc71"),
        ("EMA",              ema_series, "#3498db"),
    ]

    ax = axes[0]
    for label, series, color in series_list:
        steps = series.get("steps", [])
        prio = series.get("priority", [])
        changes = sum(abs(prio[i] - prio[i-1]) for i in range(1, len(prio)))
        pct = round(100 * sum(prio) / max(len(prio), 1), 1)
        ax.step(steps, prio, where="post", color=color, linewidth=2.0,
                alpha=0.85, label=f"{label} — {pct}% actif, {int(changes)} changements")

    ax.set_title("Stabilité de la décision de priorité", fontweight="bold")
    ax.set_xlabel("Step de simulation")
    ax.set_ylabel("Décision (1=ON, 0=OFF)")
    ax.set_yticks([0, 1])
    ax.legend(fontsize=8)
    ax.grid(alpha=0.3, linestyle="--")

    ax = axes[1]
    for label, series, color in series_list:
        values = series.get("filtered", []) if label != "Confidence brute" else series.get("raw", [])
        ax.hist(values, bins=20, color=color, alpha=0.55,
                label=label, edgecolor="white")

    ax.axvline(THRESHOLD, color="#e74c3c", linestyle="--",
               linewidth=2, label=f"Seuil θ={THRESHOLD}")
    ax.set_title("Distribution des scores utilisés", fontweight="bold")
    ax.set_xlabel("Valeur de confiance")
    ax.set_ylabel("Fréquence")
    ax.legend(fontsize=8)
    ax.grid(alpha=0.3, linestyle="--")

    plt.tight_layout()
    path = "figures/kalman_ema_fig3_robustesse.png"
    plt.savefig(path, bbox_inches="tight")
    plt.close()
    print(f"✅ Figure 3 exportée : {path}")



# =========================
# EXPORT CSV
# =========================
def export_csv(all_metrics):
    for r in all_metrics:
        fname = f"kalman_results_{r['mode']}.csv"
        with open(fname, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=r.keys())
            writer.writeheader()
            writer.writerow(r)
        print(f"✅ CSV : {fname}")

    all_fields = []
    for r in all_metrics:
        for k in r.keys():
            if k not in all_fields:
                all_fields.append(k)

    with open("kalman_comparison.csv", "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=all_fields)
        writer.writeheader()
        for r in all_metrics:
            writer.writerow({field: r.get(field, "N/A") for field in all_fields})
    print(f"✅ CSV global : kalman_comparison.csv")


# =========================
# AFFICHAGE CONSOLE
# =========================
def print_results(all_metrics):
    print("\n" + "="*95)
    print(f"{'MODE':<14} {'EV TIME':>12} {'EV WAIT':>12} {'DÉLAI CIVIL':>14} "
          f"{'FILES':>10} {'PRIORITÉ %':>12}")
    print("="*95)
    for r in all_metrics:
        ev_t  = f"{r['ev_travel_time']} steps" if r['ev_travel_time'] else "N/A"
        pct   = f"{r.get('priority_active_pct', 'N/A')}%"
        print(f"{r['mode']:<14} {ev_t:>12} {r['ev_waiting_time']:>11} s "
              f"{r['avg_normal_delay']:>13} s {r['avg_queue_length']:>8} véh {pct:>12}")

    conf = next((r for r in all_metrics if r["mode"] == "confidence"), None)
    kalm = next((r for r in all_metrics if r["mode"] == "kalman"), None)
    ema  = next((r for r in all_metrics if r["mode"] == "ema"), None)
    if conf and kalm and ema and "nb_faux_negatifs" in conf:
        print(f"\n── Comparaison des filtres ───────────────────────────────")
        print(f"  Faux négatifs YOLO        : {kalm['nb_faux_negatifs']} frames")
        print(f"  Std brute                 : {conf['conf_filtered_std']}")
        print(f"  Std Kalman                : {kalm['conf_filtered_std']}")
        print(f"  Std EMA                   : {ema['conf_filtered_std']}")
        print(f"  Coupures évitées Kalman   : {kalm['nb_coupures_evitees']} frames")
        print(f"  Coupures évitées EMA      : {ema['nb_coupures_evitees']} frames")
        print(f"  Priorité active brute     : {conf.get('priority_active_pct')}%")
        print(f"  Priorité active Kalman    : {kalm.get('priority_active_pct')}%")
        print(f"  Priorité active EMA       : {ema.get('priority_active_pct')}%")

    bl = next((r for r in all_metrics if r["mode"] == "baseline"), None)
    if bl and kalm and bl["ev_travel_time"] and kalm["ev_travel_time"]:
        gain = round((bl["ev_travel_time"] - kalm["ev_travel_time"]) / bl["ev_travel_time"] * 100, 1)
        print(f"  Gain Kalman vs Baseline: -{gain}% temps de parcours EV")
    print("="*95)


# =========================
# CORPS PRINCIPAL
# =========================
def main():
    print("\n🚀 Simulation SUMO — Comparaison Kalman vs EMA — Réseau 2 Intersections\n")
    print(f"   Route ambulance : {' → '.join(AMBULANCE_ROUTE)}\n")

    all_metrics   = []
    conf_series   = {}
    kalman_series = {}
    ema_series    = {}

    for scenario in SCENARIOS:
        mode  = scenario["mode"]
        label = scenario["label"]

        print(f"\n{'='*45}")
        print(f"Lancement : {label}")
        print(f"{'='*45}")

        result = run_simulation(mode, seed=42)
        metrics = result["metrics"]
        series  = result["series"]
        all_metrics.append(metrics)

        if mode == "confidence":
            conf_series = series
        if mode == "kalman":
            kalman_series = series
        if mode == "ema":
            ema_series = series

        print(f"  EV travel time  : {metrics['ev_travel_time']} steps")
        print(f"  EV waiting time : {metrics['ev_waiting_time']} s")
        print(f"  Délai civil moy : {metrics['avg_normal_delay']} s")
        print(f"  File moyenne    : {metrics['avg_queue_length']} véh")
        if "priority_active_pct" in metrics:
            print(f"  Priorité active : {metrics['priority_active_pct']}% du temps")

    print_results(all_metrics)
    export_csv(all_metrics)

    print("\n📊 Génération des graphiques...")
    fig1_series_comparison(conf_series, kalman_series, ema_series)
    fig2_kpi_comparison(all_metrics)
    fig3_robustesse(conf_series, kalman_series, ema_series)

    print(f"\n✅ Terminé !")


if __name__ == "__main__":
    main()