"""
=============================================================
  PFA – Partie A – Génération des figures de comparaison
  Input  : partieA_results.csv
  Output : figures_partieA/*.png
  Usage  : python generate_figures_partieA.py
=============================================================
"""
import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

# ── Config ───────────────────────────────────────────────────
INPUT_CSV  = "partieA_results.csv"
OUTPUT_DIR = "figures_partieA"
os.makedirs(OUTPUT_DIR, exist_ok=True)

TRAFFIC_ORDER  = ["faible", "moyen", "dense"]
TRAFFIC_LABELS = {"faible": "Trafic faible", "moyen": "Trafic moyen", "dense": "Trafic dense"}

MODE_ORDER  = ["baseline", "auto", "conf_0.6", "conf_0.7", "conf_0.8"]
MODE_COLORS = {
    "baseline" : "#e74c3c",
    "auto"     : "#2ecc71",
    "conf_0.6" : "#3498db",
    "conf_0.7" : "#f39c12",
    "conf_0.8" : "#9b59b6",
}
MODE_LABELS = {
    "baseline" : "Baseline\n(sans priorité)",
    "auto"     : "Auto\n(priorité totale)",
    "conf_0.6" : "Confidence\nθ=0.60",
    "conf_0.7" : "Confidence\nθ=0.70",
    "conf_0.8" : "Confidence\nθ=0.80",
}

plt.rcParams.update({
    "font.family"     : "DejaVu Sans",
    "font.size"       : 11,
    "axes.titlesize"  : 13,
    "axes.labelsize"  : 11,
    "figure.dpi"      : 150,
    "axes.spines.top" : False,
    "axes.spines.right": False,
})


# ── Chargement ───────────────────────────────────────────────
def load():
    df = pd.read_csv(INPUT_CSV)
    def make_key(row):
        if row["mode"] == "baseline": return "baseline"
        if row["mode"] == "auto":     return "auto"
        t = str(round(float(row["threshold"]), 1))
        return f"conf_{t}"
    df["mode_key"] = df.apply(make_key, axis=1)
    for c in ["ev_travel_time","ev_waiting_time","avg_civil_delay","avg_queue_length"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    print(f"[OK] {len(df)} simulations chargees")
    print(f"     Modes    : {sorted(df['mode_key'].unique())}")
    print(f"     Trafics  : {sorted(df['traffic_level'].unique())}")
    print(f"     Seeds    : {sorted(df['seed'].unique())}\n")
    return df


# ── Calcul moyenne ± std ─────────────────────────────────────
def agg(df, mode_key, traffic, metric):
    sub = df[(df["mode_key"] == mode_key) & (df["traffic_level"] == traffic)][metric]
    sub = sub.dropna()
    if sub.empty:
        return 0.0, 0.0
    return sub.mean(), sub.std()


# ── FIGURE 1 : KPIs par niveau de trafic (3×4 subplots) ──────
def fig1_kpis(df):
    metrics = [
        ("ev_travel_time",   "Temps de parcours EV (steps)"),
        ("ev_waiting_time",  "Temps d'attente EV (s)"),
        ("avg_civil_delay",  "Délai moyen trafic civil (s)"),
        ("avg_queue_length", "File d'attente moyenne (véh)"),
    ]

    present = [m for m in MODE_ORDER if m in df["mode_key"].values]
    x = np.arange(len(present))
    w = 0.55

    fig, axes = plt.subplots(
        len(metrics), len(TRAFFIC_ORDER),
        figsize=(16, 14), sharey="row"
    )
    fig.suptitle(
        "Comparaison des 3 Modes de Préemption — KPIs par Niveau de Trafic",
        fontsize=15, fontweight="bold", y=1.01
    )

    for row, (metric, metric_label) in enumerate(metrics):
        for col, traffic in enumerate(TRAFFIC_ORDER):
            ax = axes[row][col]
            means, stds = [], []
            for mk in present:
                m, s = agg(df, mk, traffic, metric)
                means.append(m)
                stds.append(s)

            colors = [MODE_COLORS.get(m, "#aaa") for m in present]
            bars = ax.bar(x, means, w, color=colors, alpha=0.85,
                          yerr=stds, capsize=4,
                          error_kw={"elinewidth":1.5, "alpha":0.7},
                          edgecolor="white", linewidth=0.8)

            for bar, val in zip(bars, means):
                if val > 0:
                    ax.text(
                        bar.get_x() + bar.get_width()/2,
                        bar.get_height() + max(means)*0.02,
                        f"{val:.1f}",
                        ha="center", va="bottom",
                        fontsize=8, fontweight="bold"
                    )

            if row == 0:
                ax.set_title(TRAFFIC_LABELS[traffic], fontweight="bold", pad=8)
            if col == 0:
                ax.set_ylabel(metric_label, fontsize=10)

            ax.set_xticks(x)
            ax.set_xticklabels(
                [MODE_LABELS.get(m,"").replace("\n"," ") for m in present],
                rotation=25, ha="right", fontsize=8
            )
            ax.grid(axis="y", alpha=0.3, linestyle="--")
            ax.set_ylim(bottom=0)

    handles = [
        mpatches.Patch(color=MODE_COLORS.get(m,"#aaa"),
                       label=MODE_LABELS.get(m,m).replace("\n"," "))
        for m in present
    ]
    fig.legend(handles=handles, loc="lower center", ncol=len(present),
               bbox_to_anchor=(0.5, -0.02), fontsize=9, frameon=True)

    plt.tight_layout()
    p = f"{OUTPUT_DIR}/fig1_kpis_par_trafic.png"
    plt.savefig(p, bbox_inches="tight")
    plt.close()
    print(f"[OK] {p}")


# ── FIGURE 2 : EV time & civil delay côte à côte ─────────────
def fig2_ev_vs_civil(df):
    present = [m for m in MODE_ORDER if m in df["mode_key"].values]
    x  = np.arange(len(TRAFFIC_ORDER))
    w  = 0.14
    offset_start = -(len(present)-1) * w / 2

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))
    fig.suptitle(
        "Impact de la Stratégie de Préemption sur l'EV et le Trafic Civil",
        fontsize=14, fontweight="bold"
    )

    for ax, metric, title, unit in [
        (ax1, "ev_travel_time",  "Temps de parcours EV", "steps"),
        (ax2, "avg_civil_delay", "Délai moyen trafic civil", "s"),
    ]:
        for i, mk in enumerate(present):
            means = [agg(df, mk, t, metric)[0] for t in TRAFFIC_ORDER]
            stds  = [agg(df, mk, t, metric)[1] for t in TRAFFIC_ORDER]
            offset = offset_start + i * w
            ax.bar(
                x + offset, means, w,
                color=MODE_COLORS.get(mk,"#aaa"),
                alpha=0.85,
                yerr=stds, capsize=3,
                error_kw={"elinewidth":1.2},
                label=MODE_LABELS.get(mk,"").replace("\n"," "),
                edgecolor="white"
            )

        ax.set_title(f"{title} ({unit})", fontweight="bold")
        ax.set_xticks(x)
        ax.set_xticklabels(
            [TRAFFIC_LABELS[t] for t in TRAFFIC_ORDER],
            fontsize=11
        )
        ax.set_ylabel(f"{title} ({unit})")
        ax.grid(axis="y", alpha=0.3, linestyle="--")
        ax.set_ylim(bottom=0)

    handles = [
        mpatches.Patch(color=MODE_COLORS.get(m,"#aaa"),
                       label=MODE_LABELS.get(m,m).replace("\n"," "))
        for m in present
    ]
    fig.legend(handles=handles, loc="lower center", ncol=len(present),
               bbox_to_anchor=(0.5, -0.06), fontsize=9, frameon=True)

    plt.tight_layout()
    p = f"{OUTPUT_DIR}/fig2_ev_vs_civil.png"
    plt.savefig(p, bbox_inches="tight")
    plt.close()
    print(f"[OK] {p}")


# ── FIGURE 3 : Sensibilité au seuil θ ────────────────────────
def fig3_seuil(df):
    conf_keys = ["conf_0.6", "conf_0.7", "conf_0.8"]
    thresholds = [0.60, 0.70, 0.80]
    present_conf = [k for k in conf_keys if k in df["mode_key"].values]

    fig, axes = plt.subplots(
        2, len(TRAFFIC_ORDER),
        figsize=(15, 9)
    )
    fig.suptitle(
        "Sensibilité au Seuil θ — EV time et Délai Civil par Niveau de Trafic",
        fontsize=14, fontweight="bold"
    )

    metrics = [
        ("ev_travel_time",  "Temps de parcours EV (steps)"),
        ("avg_civil_delay", "Délai moyen trafic civil (s)"),
    ]

    for row, (metric, metric_label) in enumerate(metrics):
        for col, traffic in enumerate(TRAFFIC_ORDER):
            ax = axes[row][col]

            # Ligne confidence (3 seuils)
            means = []
            stds  = []
            for mk in present_conf:
                m, s = agg(df, mk, traffic, metric)
                means.append(m)
                stds.append(s)

            ax.plot(thresholds[:len(present_conf)], means,
                    marker="o", linewidth=2.5, color="#3498db",
                    markersize=8, label="Confidence θ")
            ax.fill_between(
                thresholds[:len(present_conf)],
                [m-s for m,s in zip(means,stds)],
                [m+s for m,s in zip(means,stds)],
                alpha=0.15, color="#3498db"
            )

            # Annotations
            for t, m in zip(thresholds[:len(present_conf)], means):
                ax.annotate(f"{m:.1f}", (t, m),
                            textcoords="offset points", xytext=(0,10),
                            ha="center", fontsize=9, fontweight="bold")

            # Lignes de référence
            bl_m, _ = agg(df, "baseline", traffic, metric)
            au_m, _ = agg(df, "auto",     traffic, metric)
            if bl_m > 0:
                ax.axhline(bl_m, color="#e74c3c", linestyle="--",
                           linewidth=1.5, label=f"Baseline ({bl_m:.1f})")
            if au_m > 0:
                ax.axhline(au_m, color="#2ecc71", linestyle="--",
                           linewidth=1.5, label=f"Auto ({au_m:.1f})")

            if row == 0:
                ax.set_title(TRAFFIC_LABELS[traffic], fontweight="bold")
            if col == 0:
                ax.set_ylabel(metric_label, fontsize=10)

            ax.set_xlabel("Seuil θ")
            ax.set_xticks(thresholds)
            ax.legend(fontsize=8)
            ax.grid(alpha=0.3, linestyle="--")

    plt.tight_layout()
    p = f"{OUTPUT_DIR}/fig3_sensibilite_seuil.png"
    plt.savefig(p, bbox_inches="tight")
    plt.close()
    print(f"[OK] {p}")


# ── FIGURE 4 : Tableau synthèse (heatmap) ────────────────────
def fig4_heatmap(df):
    present = [m for m in MODE_ORDER if m in df["mode_key"].values]
    metrics = ["ev_travel_time", "ev_waiting_time", "avg_civil_delay", "avg_queue_length"]
    m_labels = ["EV time (steps)", "EV wait (s)", "Délai civil (s)", "Queue (véh)"]

    for traffic in TRAFFIC_ORDER:
        data = []
        for mk in present:
            row_data = []
            for metric in metrics:
                m, _ = agg(df, mk, traffic, metric)
                row_data.append(m)
            data.append(row_data)

        data_arr = np.array(data, dtype=float)

        # Normalisation par colonne pour la heatmap (0=meilleur, 1=pire)
        norm = np.zeros_like(data_arr)
        for j in range(data_arr.shape[1]):
            col = data_arr[:, j]
            rng = col.max() - col.min()
            norm[:, j] = (col - col.min()) / rng if rng > 0 else 0.0

        fig, ax = plt.subplots(figsize=(10, 5))
        im = ax.imshow(norm.T, cmap="RdYlGn_r", aspect="auto",
                       vmin=0, vmax=1)

        ax.set_xticks(range(len(present)))
        ax.set_xticklabels(
            [MODE_LABELS.get(m,"").replace("\n"," ") for m in present],
            rotation=20, ha="right", fontsize=10
        )
        ax.set_yticks(range(len(metrics)))
        ax.set_yticklabels(m_labels, fontsize=10)

        # Valeurs dans chaque cellule
        for i in range(len(present)):
            for j in range(len(metrics)):
                ax.text(i, j, f"{data_arr[i,j]:.1f}",
                        ha="center", va="center",
                        fontsize=10, fontweight="bold",
                        color="black")

        plt.colorbar(im, ax=ax, label="Score normalisé (rouge=pire, vert=meilleur)")
        ax.set_title(
            f"Tableau de Performance — {TRAFFIC_LABELS[traffic]}\n"
            "(valeurs réelles, couleur = rang normalisé)",
            fontweight="bold", pad=10
        )
        plt.tight_layout()
        p = f"{OUTPUT_DIR}/fig4_heatmap_{traffic}.png"
        plt.savefig(p, bbox_inches="tight")
        plt.close()
        print(f"[OK] {p}")


# ── FIGURE 5 : Gain % vs Baseline ────────────────────────────
def fig5_gain(df):
    present_no_bl = [m for m in MODE_ORDER if m != "baseline"
                     and m in df["mode_key"].values]

    fig, axes = plt.subplots(1, len(TRAFFIC_ORDER), figsize=(15, 6), sharey=True)
    fig.suptitle(
        "Gain en Temps de Parcours EV vs Baseline (%)\n"
        "(négatif = amélioration)",
        fontsize=14, fontweight="bold"
    )

    for ax, traffic in zip(axes, TRAFFIC_ORDER):
        bl_m, _ = agg(df, "baseline", traffic, "ev_travel_time")
        gains = []
        for mk in present_no_bl:
            m, _ = agg(df, mk, traffic, "ev_travel_time")
            g = ((m - bl_m) / bl_m * 100) if bl_m > 0 else 0
            gains.append(g)

        colors = [
            "#2ecc71" if g <= 0 else "#e74c3c"
            for g in gains
        ]
        bars = ax.bar(range(len(present_no_bl)), gains,
                      color=colors, alpha=0.85,
                      edgecolor="white")

        for i, (bar, g) in enumerate(zip(bars, gains)):
            va  = "bottom" if g >= 0 else "top"
            yp  = g + 0.5 if g >= 0 else g - 0.5
            ax.text(i, yp, f"{g:.1f}%",
                    ha="center", va=va,
                    fontsize=9, fontweight="bold")

        ax.axhline(0, color="black", linewidth=1.2)
        ax.set_title(TRAFFIC_LABELS[traffic], fontweight="bold")
        ax.set_xticks(range(len(present_no_bl)))
        ax.set_xticklabels(
            [MODE_LABELS.get(m,"").replace("\n"," ") for m in present_no_bl],
            rotation=20, ha="right", fontsize=9
        )
        ax.grid(axis="y", alpha=0.3, linestyle="--")
        if ax == axes[0]:
            ax.set_ylabel("Gain EV time vs Baseline (%)")

    plt.tight_layout()
    p = f"{OUTPUT_DIR}/fig5_gain_vs_baseline.png"
    plt.savefig(p, bbox_inches="tight")
    plt.close()
    print(f"[OK] {p}")


# ── Export CSV resume ─────────────────────────────────────────
def export_summary(df):
    present = [m for m in MODE_ORDER if m in df["mode_key"].values]
    rows = []
    for traffic in TRAFFIC_ORDER:
        for mk in present:
            for metric in ["ev_travel_time","ev_waiting_time","avg_civil_delay","avg_queue_length"]:
                m, s = agg(df, mk, traffic, metric)
                rows.append({
                    "trafic"      : traffic,
                    "mode"        : mk,
                    "metric"      : metric,
                    "mean"        : round(m, 2),
                    "std"         : round(s, 2),
                    "mean_std"    : f"{m:.1f} ± {s:.1f}",
                })
    pd.DataFrame(rows).to_csv(f"{OUTPUT_DIR}/summary_stats.csv", index=False)
    print(f"[OK] {OUTPUT_DIR}/summary_stats.csv")


# ── Main ──────────────────────────────────────────────────────
def main():
    print("\n" + "="*60)
    print("  PFA – Partie A – Génération des figures")
    print("="*60 + "\n")

    df = load()
    export_summary(df)
    fig1_kpis(df)
    fig2_ev_vs_civil(df)
    fig3_seuil(df)
    fig4_heatmap(df)
    fig5_gain(df)

    print(f"\n[DONE] Figures dans : {OUTPUT_DIR}/")
    print("  fig1_kpis_par_trafic.png   — KPIs x modes x niveaux trafic")
    print("  fig2_ev_vs_civil.png       — EV time et délai civil comparés")
    print("  fig3_sensibilite_seuil.png — Sensibilité au seuil θ")
    print("  fig4_heatmap_*.png         — Tableau coloré par niveau de trafic")
    print("  fig5_gain_vs_baseline.png  — Gain % vs Baseline")
    print("  summary_stats.csv          — Toutes les stats moyenne ± std")


if __name__ == "__main__":
    main()
