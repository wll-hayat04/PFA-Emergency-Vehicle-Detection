import pygame
import pygame.gfxdraw
import sys
import math
import random

pygame.init()

WIDTH, HEIGHT = 1500, 880
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Smart Traffic Decision System — YOLO26 Priority")
clock = pygame.time.Clock()

# ═══════════════════════════════════════════
#  PALETTE
# ═══════════════════════════════════════════
C = {
    "bg_sky":       (210, 225, 240),
    "grass":        (118, 194, 112),
    "grass_s":      ( 88, 158,  84),
    "grass_e":      ( 72, 138,  70),
    "asphalt":      ( 45,  58,  76),
    "asphalt_int":  ( 36,  47,  62),
    "asphalt_s":    ( 28,  38,  52),
    "asphalt_e":    ( 22,  30,  42),
    "road_mark":    (230, 238, 248),
    "yellow":       (252, 196,  42),
    "building":     (200, 214, 230),
    "building_l":   (158, 174, 194),
    "building_r":   (175, 192, 212),
    "roof_green":   (130, 180, 128),
    "red":          (228,  52,  52),
    "green":        ( 38, 210,  92),
    "blue":         ( 52, 140, 245),
    "orange":       (248, 162,  38),
    "amber":        (245, 185,  48),
    "dark_red":     ( 80,  14,  14),
    "dark_green":   (  8,  60,  28),
    "panel":        (242, 247, 254),
    "panel_border": (165, 182, 208),
    "text":         ( 26,  36,  52),
    "muted":        ( 92, 108, 132),
    "ev_blue":      ( 62, 152, 255),
    "ev_red":       (235,  55,  55),
    "purple":       (140,  80, 220),
    "heat_green":   ( 60, 200, 100),
    "heat_orange":  (250, 160,  45),
    "heat_red":     (235,  60,  60),
}

# ═══════════════════════════════════════════
#  FONTS
# ═══════════════════════════════════════════
def load_font(name, size, bold=False):
    for f in [name, "Segoe UI", "Arial"]:
        try:   return pygame.font.SysFont(f, size, bold=bold)
        except: pass
    return pygame.font.Font(None, size)

F = {
    "title": load_font("Rajdhani", 24, True),
    "lg":    load_font("Rajdhani", 19, True),
    "md":    load_font("Rajdhani", 16),
    "sm":    load_font("Consolas", 13),
    "xs":    load_font("Consolas", 11),
}

# ═══════════════════════════════════════════
#  ISO MATH
# ═══════════════════════════════════════════
ISO_X = WIDTH  // 2
ISO_Y = HEIGHT // 2 - 55
ISO_S = 1.08

def iso(wx, wy):
    sx = (wx - wy) * math.cos(math.pi / 6) * ISO_S
    sy = (wx + wy) * math.sin(math.pi / 6) * ISO_S * 0.58
    return (ISO_X + sx, ISO_Y + sy)

def iso_pts(wx, wy, ww, wh):
    return [iso(wx,wy), iso(wx+ww,wy), iso(wx+ww,wy+wh), iso(wx,wy+wh)]

def iso_face(wx, wy, ww, wh, color):
    pygame.draw.polygon(screen, color, iso_pts(wx,wy,ww,wh))

def iso_box(wx, wy, ww, wh, h3, top, left, right):
    pts = iso_pts(wx,wy,ww,wh)
    pygame.draw.polygon(screen, top,   pts)
    bl,br = pts[3],pts[2]
    pygame.draw.polygon(screen, left,  [bl,br,(br[0],br[1]+h3),(bl[0],bl[1]+h3)])
    tr = pts[1]
    pygame.draw.polygon(screen, right, [br,tr,(tr[0],tr[1]+h3),(br[0],br[1]+h3)])
    return pts

def draw_dash_iso(wx1,wy1,wx2,wy2,color,dl=18,gl=12,lw=2):
    p1,p2=iso(wx1,wy1),iso(wx2,wy2)
    dx,dy=p2[0]-p1[0],p2[1]-p1[1]
    L=math.hypot(dx,dy)
    if L==0: return
    nx,ny=dx/L,dy/L; d=0
    while d<L:
        ex=min(d+dl,L)
        pygame.draw.line(screen,color,(p1[0]+nx*d,p1[1]+ny*d),(p1[0]+nx*ex,p1[1]+ny*ex),lw)
        d+=dl+gl

def draw_line_iso(wx1,wy1,wx2,wy2,color,lw=2):
    pygame.draw.line(screen,color,iso(wx1,wy1),iso(wx2,wy2),lw)

# ═══════════════════════════════════════════
#  HELPERS
# ═══════════════════════════════════════════
def glow(x,y,r,color,alpha=90):
    s=pygame.Surface((r*2,r*2),pygame.SRCALPHA)
    pygame.draw.circle(s,(*color[:3],alpha),(r,r),r)
    screen.blit(s,(int(x-r),int(y-r)))

def alpha_rect(surface,color,rect,radius=12,alpha=220):
    s=pygame.Surface((rect[2],rect[3]),pygame.SRCALPHA)
    pygame.draw.rect(s,(*color[:3],alpha),(0,0,rect[2],rect[3]),border_radius=radius)
    surface.blit(s,(rect[0],rect[1]))

def txt(text,pos,font,color=None,center=False,shadow=False):
    color=color or C["text"]
    if shadow:
        ss=font.render(text,True,(0,0,0,80)); sr=ss.get_rect()
        if center: sr.center=(pos[0]+1,pos[1]+1)
        else:      sr.topleft=(pos[0]+1,pos[1]+1)
        screen.blit(ss,sr)
    s=font.render(text,True,color); r=s.get_rect()
    if center: r.center=pos
    else:      r.topleft=pos
    screen.blit(s,r); return r

def draw_btn(rect, label, color, active=False, hover=False):
    """Draw a modern button, return rect for hit-testing."""
    r = pygame.Rect(rect)
    bg = color if active else (38,50,70)
    if hover and not active: bg = tuple(min(255,c+20) for c in bg)
    alpha_rect(screen, bg, rect, radius=10, alpha=240)
    border_col = color if active else C["panel_border"]
    pygame.draw.rect(screen, border_col, rect, 2, border_radius=10)
    if active:
        glow(r.centerx, r.centery, r.width//2, color, 60)
    txt(label, (r.centerx, r.centery), F["sm"],
        (255,255,255) if active else C["muted"], center=True)
    return r

# ═══════════════════════════════════════════
#  WORLD CONSTANTS
# ═══════════════════════════════════════════
RH      = 215
LW      = 54
IH      = 88
RW      = IH + LW
DET_WY  = 310
DET_WH  = 170
STOP_WY = 170
CLEAR_WY= -135
MIN_GAP = 0.32
CAR_SPD = 1.8
EV_SPD  = 3.2
EV_PRIO = 4.5
BASELINE_RELEASE_AFTER = 5.0

# ═══════════════════════════════════════════
#  STATE
# ═══════════════════════════════════════════
# Mode: "baseline" | "auto" | "confidence"
MODE      = "confidence"
THRESHOLD = 0.70
CONF      = 0.71
CONF_VALS = [0.55, 0.71, 0.94]
conf_idx  = 1
priority  = False
paused    = False
ev_wait   = 0.0
ev_travel = 0
ev_t      = 1.6
blocked   = 0
frame     = 0
siren_t   = 0.0
notification_timer = 0
prev_priority      = False
baseline_released = False
event_log = []
ev_detected_logged = False
priority_logged = False
crossed_logged = False
light_transition_timer = 0
last_run_summary = None
kpi_timer = 0

# ── Per-mode stats (accumulated over runs) ──
stats = {
    "baseline":   {"ev_wait_total":0,"ev_travel_total":0,"runs":0,"blocked_total":0},
    "auto":       {"ev_wait_total":0,"ev_travel_total":0,"runs":0,"blocked_total":0},
    "confidence": {"ev_wait_total":0,"ev_travel_total":0,"runs":0,"blocked_total":0},
}

# ── Mouse hover tracking ──
mouse_pos = (0,0)

# ═══════════════════════════════════════════
#  CARS
# ═══════════════════════════════════════════
CAR_COLORS = [
    ( 42,120,210),( 55, 70, 90),( 38,115,200),( 30, 80,180),
    ( 70, 80,100),(210,160, 30),(160, 90,180),( 40,140,120),
]

def make_cars():
    return [
        {"t":-1.30,"lane":0,"spd": CAR_SPD,"col":CAR_COLORS[0],"type":"sedan","is_blocked":False},
        {"t":-0.90,"lane":0,"spd": CAR_SPD,"col":CAR_COLORS[1],"type":"suv",  "is_blocked":False},
        {"t":-0.50,"lane":0,"spd": CAR_SPD,"col":CAR_COLORS[2],"type":"sedan","is_blocked":False},
        {"t": 1.30,"lane":1,"spd":-CAR_SPD,"col":CAR_COLORS[3],"type":"suv",  "is_blocked":False},
        {"t": 0.90,"lane":1,"spd":-CAR_SPD,"col":CAR_COLORS[4],"type":"sedan","is_blocked":False},
        {"t": 0.50,"lane":1,"spd":-CAR_SPD,"col":CAR_COLORS[5],"type":"suv",  "is_blocked":False},
        {"t":-1.00,"lane":2,"spd": CAR_SPD,"col":CAR_COLORS[6],"type":"sedan","is_blocked":False},
        {"t":-1.40,"lane":2,"spd": CAR_SPD,"col":CAR_COLORS[7],"type":"suv",  "is_blocked":False},
    ]

cars = make_cars()

def reset(keep_stats=True):
    global cars,ev_t,ev_wait,ev_travel,priority,blocked,frame,siren_t
    global notification_timer,prev_priority,baseline_released
    global event_log,ev_detected_logged,priority_logged,crossed_logged
    global light_transition_timer,last_run_summary,kpi_timer
    cars=make_cars(); ev_t=1.6; ev_wait=0.0; ev_travel=0
    priority=False; blocked=0; frame=0; siren_t=0.0
    notification_timer=0; prev_priority=False; baseline_released=False
    event_log=[]; ev_detected_logged=False; priority_logged=False; crossed_logged=False
    light_transition_timer=0
    last_run_summary=None
    kpi_timer=0

# ═══════════════════════════════════════════
#  WORLD POSITIONS
# ═══════════════════════════════════════════
def hcar_world(car):
    wy=-LW*0.45 if car["lane"]==0 else LW*0.45
    return car["t"]*RH*2.2, wy

def vcar_world(car):
    return LW*0.45, car["t"]*RH*2.2

def ev_world():
    return -LW*0.38, ev_t*RH*2.1

# ═══════════════════════════════════════════
#  DRAW — BG + ENVIRONMENT
# ═══════════════════════════════════════════
def draw_bg():
    for y in range(0,HEIGHT,3):
        t=y/HEIGHT
        screen.fill((int(210+(195-210)*t),int(225+(215-225)*t),int(240+(230-240)*t)),(0,y,WIDTH,3))

def draw_environment():
    for gx,gy in [(-560,-560),(-560,110),(110,-560),(110,110)]:
        iso_box(gx,gy,185,185,0,C["grass"],C["grass_s"],C["grass_e"])
    for tx,ty in [(-480,-480),(-400,-500),(-320,-460),(340,-460),(420,-490),(340,340),(-400,370)]:
        p=iso(tx,ty); px,py=int(p[0]),int(p[1])
        pygame.draw.rect(screen,(120,85,55),(px-3,py-2,6,18))
        for i,size in enumerate([28,22,16]):
            pygame.draw.polygon(screen,(80+i*10,160+i*8,75+i*5),
                [(px,py-18-i*10),(px-size,py-8-i*10+size//2),(px+size,py-8-i*10+size//2)])
    for bx,by,bw,bh,bh3 in [(-800,-730,270,250,58),(-780,-400,210,210,44),
        (410,-730,290,250,62),(400,-380,230,210,46),(-710,380,250,220,52),(370,390,260,220,54)]:
        iso_box(bx,by,bw,bh,bh3,C["building"],C["building_l"],C["building_r"])
        iso_box(bx+10,by+10,bw-20,bh-20,4,C["roof_green"],C["grass_s"],C["grass_e"])
        for wi in range(3):
            for wj in range(2):
                wx2=bx+28+wi*62; wy2=by+30+wj*65
                if wx2+30<bx+bw and wy2+22<by+bh:
                    iso_box(wx2,wy2,28,20,0,(175,200,228),(135,162,192),(155,182,210))

def draw_roads():
    iso_box(-RH*2.3,-RW,RH*4.6,RW*2,0,C["asphalt"],C["asphalt_s"],C["asphalt_e"])
    iso_box(-RW,-RH*2.3,RW*2,RH*4.6,0,C["asphalt"],C["asphalt_s"],C["asphalt_e"])
    iso_box(-RW,-RW,RW*2,RW*2,0,C["asphalt_int"],C["asphalt_s"],C["asphalt_e"])
    draw_dash_iso(-RH*2.3,0,-RW,0,C["road_mark"],20,14,2)
    draw_dash_iso(RW,0,RH*2.3,0,C["road_mark"],20,14,2)
    draw_dash_iso(0,-RH*2.3,0,-RW,C["road_mark"],20,14,2)
    draw_dash_iso(0,RW,0,RH*2.3,C["road_mark"],20,14,2)
    for wy2 in [LW*0.5,-LW*0.5]:
        draw_dash_iso(-RH*2.3,wy2,-RW,wy2,C["yellow"],22,10,3)
        draw_dash_iso(RW,wy2,RH*2.3,wy2,C["yellow"],22,10,3)
    for wx2 in [LW*0.5,-LW*0.5]:
        draw_dash_iso(wx2,-RH*2.3,wx2,-RW,C["yellow"],22,10,3)
        draw_dash_iso(wx2,RW,wx2,RH*2.3,C["yellow"],22,10,3)
    for i in range(7):
        sw,sg=10,9
        iso_face(-RW-52+i*(sw+sg),-RW,sw,52,(225,235,248))
        iso_face(RW+4+i*(sw+sg),-RW,sw,52,(225,235,248))
        iso_face(-RW,-RW-52+i*(sw+sg),52,sw,(225,235,248))
        iso_face(-RW,RW+4+i*(sw+sg),52,sw,(225,235,248))
    draw_line_iso(-RW,STOP_WY,RW,STOP_WY,(255,220,50),3)
    for wx2,wy2,d in [(-290,LW*0.5,"right"),(290,-LW*0.5,"left"),(-LW*0.38,250,"up")]:
        p=iso(wx2,wy2); s=pygame.Surface((70,70),pygame.SRCALPHA)
        pts={"right":[(58,35),(36,22),(36,48)],"left":[(12,35),(34,22),(34,48)],"up":[(35,12),(22,34),(48,34)]}[d]
        pygame.draw.polygon(s,(255,255,255,70),pts); screen.blit(s,(int(p[0])-35,int(p[1])-35))

def draw_yolo_zone():
    wx,wy,ww,wh=-IH,DET_WY,IH*2,DET_WH
    pts=iso_pts(wx,wy,ww,wh)
    s=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA)
    pygame.draw.polygon(s,(*C["orange"],35),pts); screen.blit(s,(0,0))
    loop=pts+[pts[0]]
    for i in range(len(loop)-1):
        dx=loop[i+1][0]-loop[i][0]; dy=loop[i+1][1]-loop[i][1]
        L=math.hypot(dx,dy)
        if L==0: continue
        nx,ny=dx/L,dy/L; d=0
        while d<L:
            ex=min(d+9,L)
            pygame.draw.line(screen,C["orange"],(loop[i][0]+nx*d,loop[i][1]+ny*d),(loop[i][0]+nx*ex,loop[i][1]+ny*ex),2)
            d+=17
    lp=iso(wx+ww/2,wy+wh+12)
    txt("YOLO ANALYSIS ZONE",(int(lp[0])-75,int(lp[1])),F["xs"],C["orange"])

def draw_tl(wx, wy, state, is_ev=False):
    """Traffic light with red / amber / green states."""
    if isinstance(state, bool):
        state = "green" if state else "red"

    p = iso(wx, wy)
    px, py = int(p[0]), int(p[1])
    pygame.draw.rect(screen, (62, 75, 92), (px-4, py-92, 8, 92), border_radius=4)
    pygame.draw.rect(screen, (62, 75, 92), (px-4, py-92, 22, 7), border_radius=3)
    pygame.draw.rect(screen, (22, 32, 48), (px+10, py-108, 32, 84), border_radius=9)
    pygame.draw.rect(screen, (45, 58, 78), (px+10, py-108, 32, 84), 2, border_radius=9)

    cx2 = px + 26

    red_on = state == "red"
    pygame.draw.circle(screen, C["red"] if red_on else C["dark_red"], (cx2, py-94), 10)
    if red_on:
        glow(cx2, py-94, 28, C["red"], 95)

    amber_on = state == "amber"
    pygame.draw.circle(screen, C["amber"] if amber_on else (85, 60, 10), (cx2, py-70), 10)
    if amber_on:
        glow(cx2, py-70, 28, C["amber"], 105)

    green_on = state == "green"
    pygame.draw.circle(screen, C["green"] if green_on else C["dark_green"], (cx2, py-46), 10)
    if green_on:
        glow(cx2, py-46, 36 if is_ev else 30, C["green"], 120 if is_ev else 100)

    if is_ev:
        txt("EV", (px-2, py-118), F["xs"], C["amber"])


def draw_lights():
    """Draw lights with amber transition and EV green phase."""
    ev_phase = priority or baseline_released

    if light_transition_timer > 0:
        normal_state = "amber"
        ev_state = "amber"
    else:
        normal_state = "red" if ev_phase else "green"
        ev_state = "green" if ev_phase else "red"

    draw_tl(-IH-40, -IH-40, normal_state)
    draw_tl(IH+12, -IH-40, normal_state)
    draw_tl(-IH-40, IH+12, normal_state)
    draw_tl(-IH+10, IH+50, ev_state, is_ev=True)


# ═══════════════════════════════════════════
#  DRAW — VEHICLES
# ═══════════════════════════════════════════
def _iso_car_body(wx,wy,ww,wh,color,is_suv=False):
    dc=tuple(max(0,c-40) for c in color)
    dc2=tuple(max(0,c-22) for c in color)
    sh=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA)
    pts=iso_pts(wx,wy,ww,wh)
    pygame.draw.polygon(sh,(0,0,0,28),[(x,y+6) for x,y in pts])
    screen.blit(sh,(0,0))
    iso_box(wx,wy,ww,wh,9 if is_suv else 7,color,dc,dc2)
    pad=ww*0.18
    iso_face(wx+pad,wy+wh*0.15,ww-pad*2,wh*0.65,(165,205,235))
    if not is_suv: iso_face(wx+ww*0.6,wy+wh*0.1,ww*0.32,wh*0.8,dc)
    if is_suv:     iso_box(wx+ww*0.1,wy+wh*0.1,ww*0.8,wh*0.8,12,dc2,dc,color)

def draw_sedan(wx,wy,color,horizontal=True):
    if horizontal: _iso_car_body(wx,wy,30,15,color,False)
    else:          _iso_car_body(wx,wy,15,30,color,False)

def draw_suv(wx,wy,color,horizontal=True):
    if horizontal: _iso_car_body(wx,wy,32,17,color,True)
    else:          _iso_car_body(wx,wy,17,32,color,True)

def draw_ambulance():
    global siren_t
    wx,wy=ev_world(); ww,wh=34,56; ox,oy=wx-ww/2,wy-wh/2
    det_t=DET_WY/(RH*2.1)
    if priority or ev_t<det_t+0.15:
        pts=iso_pts(ox-10,oy-10,ww+20,wh+20)
        dash_alpha=int(180+70*math.sin(frame*0.15))
        loop=pts+[pts[0]]
        for i in range(len(loop)-1):
            dx=loop[i+1][0]-loop[i][0]; dy=loop[i+1][1]-loop[i][1]
            L=math.hypot(dx,dy)
            if L==0: continue
            nx,ny=dx/L,dy/L; d=0
            while d<L:
                ex=min(d+10,L)
                s=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA)
                pygame.draw.line(s,(62,152,255,dash_alpha),
                    (loop[i][0]+nx*d,loop[i][1]+ny*d),(loop[i][0]+nx*ex,loop[i][1]+ny*ex),3)
                screen.blit(s,(0,0)); d+=18
        lp=iso(ox+ww/2,oy-14)
        txt(f"Ambulance  {CONF*100:.0f}%",(int(lp[0])-50,int(lp[1])-14),F["sm"],C["ev_blue"],shadow=True)
    sh=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA)
    pts=iso_pts(ox,oy,ww,wh)
    pygame.draw.polygon(sh,(0,0,0,32),[(x,y+8) for x,y in pts])
    screen.blit(sh,(0,0))
    iso_box(ox,oy,ww,wh,10,(245,248,255),(210,218,230),(225,232,242))
    iso_face(ox,oy+wh*0.52,ww,wh*0.2,C["ev_red"])
    cp=iso(ox+ww/2,oy+wh*0.25); cx2,cy2=int(cp[0]),int(cp[1])
    pygame.draw.rect(screen,C["ev_red"],(cx2-2,cy2-10,4,20),border_radius=1)
    pygame.draw.rect(screen,C["ev_red"],(cx2-10,cy2-2,20,4),border_radius=1)
    iso_face(ox+ww*0.1,oy+wh*0.05,ww*0.8,wh*0.3,(170,210,240))
    siren_t+=0.12
    sl=iso(ox+4,oy+4); sr=iso(ox+ww-4,oy+4)
    slx,sly=int(sl[0]),int(sl[1])-6; srx,sry=int(sr[0]),int(sr[1])-6
    if int(siren_t)%2==0:
        glow(slx,sly,22,C["ev_blue"],int(140+80*abs(math.sin(siren_t))))
        pygame.draw.circle(screen,C["ev_blue"],(slx,sly),6)
        pygame.draw.circle(screen,(180,60,60),(srx,sry),5)
    else:
        glow(srx,sry,22,C["ev_blue"],int(140+80*abs(math.sin(siren_t))))
        pygame.draw.circle(screen,C["ev_blue"],(srx,sry),6)
        pygame.draw.circle(screen,(180,60,60),(slx,sly),5)

def draw_ev_path():
    """Trace visuelle du couloir prioritaire de l'ambulance."""
    s = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    pts = [iso(-LW*0.38, 330), iso(-LW*0.38, -150)]
    pygame.draw.line(s, (*C["ev_blue"], 90), pts[0], pts[1], 5)
    pygame.draw.line(s, (*C["ev_blue"], 35), pts[0], pts[1], 14)
    screen.blit(s, (0, 0))


def get_corridor_stage():
    """Progressive green corridor indicator based on ambulance position."""
    if not (priority or baseline_released):
        return 0
    if ev_t < 0.10:
        return 3
    if ev_t < 0.70:
        return 2
    if ev_t < 1.25:
        return 1
    return 0

def draw_green_corridor():
    """Animated progressive corridor on the EV path."""
    stage = get_corridor_stage()
    if stage <= 0:
        return

    segments = [
        (iso(-LW*0.38, 330), iso(-LW*0.38, 170)),
        (iso(-LW*0.38, 170), iso(-LW*0.38,  10)),
        (iso(-LW*0.38,  10), iso(-LW*0.38, -150)),
    ]

    s = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    pulse = int(55 + 35 * abs(math.sin(frame * 0.12)))
    for i in range(stage):
        p1, p2 = segments[i]
        pygame.draw.line(s, (*C["green"], 45 + pulse), p1, p2, 18)
        pygame.draw.line(s, (*C["green"], 140), p1, p2, 5)
    screen.blit(s, (0, 0))

def draw_radar_scan():
    """YOLO/radar pulse when the ambulance is in the detection range."""
    det_t = DET_WY / (RH * 2.1)
    if not (ev_t < det_t + 0.25):
        return

    wx, wy = ev_world()
    sx, sy = iso(wx, wy)
    radius = int(28 + 16 * abs(math.sin(frame * 0.13)))

    s = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    pygame.draw.circle(s, (*C["blue"], 70), (int(sx), int(sy)), radius, 2)
    pygame.draw.circle(s, (*C["blue"], 35), (int(sx), int(sy)), radius + 18, 2)
    pygame.draw.line(
        s,
        (*C["blue"], 95),
        (int(sx), int(sy)),
        (int(sx + math.cos(frame * 0.08) * (radius + 22)), int(sy + math.sin(frame * 0.08) * (radius + 22))),
        2,
    )
    screen.blit(s, (0, 0))

def draw_heatmap():
    """Traffic heatmap overlay: green = fluid, orange/red = disturbed."""
    if blocked == 0:
        col, alpha = C["heat_green"], 18
    elif blocked <= 2:
        col, alpha = C["heat_orange"], 34
    else:
        col, alpha = C["heat_red"], 44

    s = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    pygame.draw.polygon(s, (*col, alpha), iso_pts(-RH*2.3, -RW, RH*4.6, RW*2))
    pygame.draw.polygon(s, (*col, alpha), iso_pts(-RW, -RH*2.3, RW*2, RH*4.6))
    screen.blit(s, (0, 0))

def draw_scene():
    global blocked
    blocked=0
    render_list=[]
    for car in cars:
        is_vert=(car["lane"]==2)
        is_suv=(car["type"]=="suv")
        wx,wy=vcar_world(car) if is_vert else hcar_world(car)
        dwx=wx-8 if is_vert else wx-16
        dwy=wy-16 if is_vert else wy-8.5
        if car["is_blocked"]: blocked+=1
        col=car["col"] if not car["is_blocked"] else tuple(max(0,c-30) for c in car["col"])
        render_list.append((dwx+dwy, dwx, dwy, col, is_suv, is_vert))
    ev_wx,ev_wy=ev_world()
    render_list.append(((ev_wx-17)+(ev_wy-28), ev_wx, ev_wy, None, None, None))
    render_list.sort(key=lambda x:x[0])
    for item in render_list:
        _,dwx,dwy,col,is_suv,is_vert=item
        if col is None: draw_ambulance(); continue
        if is_vert:
            draw_suv(dwx,dwy,col,horizontal=False) if is_suv else draw_sedan(dwx,dwy,col,horizontal=False)
        else:
            draw_suv(dwx,dwy,col,horizontal=True) if is_suv else draw_sedan(dwx,dwy,col,horizontal=True)

# ═══════════════════════════════════════════
#  DRAW — DASHBOARD (left panel)
# ═══════════════════════════════════════════
btn_rects = {}   # store rects for click detection

def draw_shield(sx,sy,granted):
    col=C["green"] if granted else C["amber"]
    col2=(14,140,52) if granted else (180,110,10)
    pts=[(sx+38,sy),(sx+72,sy+14),(sx+68,sy+56),(sx+38,sy+74),(sx+8,sy+56),(sx+4,sy+14)]
    pygame.draw.polygon(screen,col,pts)
    pygame.draw.polygon(screen,col2,pts,3)
    pygame.draw.line(screen,(255,255,255),(sx+20,sy+38),(sx+34,sy+54),5)
    if granted: pygame.draw.line(screen,(255,255,255),(sx+34,sy+54),(sx+60,sy+26),5)
    else:
        pygame.draw.line(screen,(255,255,255),(sx+22,sy+26),(sx+58,sy+56),5)
        pygame.draw.line(screen,(255,255,255),(sx+58,sy+26),(sx+22,sy+56),5)

def draw_dashboard():
    x,y,w,h=18,18,415,510
    alpha_rect(screen,C["panel"],(x,y,w,h),radius=16,alpha=232)
    pygame.draw.rect(screen,C["panel_border"],(x,y,w,h),2,border_radius=16)

    # Title
    txt("SMART TRAFFIC DECISION SYSTEM",(x+20,y+16),F["title"],C["text"],shadow=True)
    pygame.draw.line(screen,C["panel_border"],(x+16,y+52),(x+w-16,y+52),1)

    # ── MODE SELECTOR ──────────────────────
    txt("MODE",(x+20,y+60),F["xs"],C["muted"])
    mode_defs=[
        ("baseline","BASELINE", C["muted"]),
        ("auto",    "AUTO",     C["blue"]),
        ("confidence","CONF",   C["green"]),
    ]
    mbx=x+20
    for key,label,col in mode_defs:
        active=(MODE==key)
        r=(mbx,y+75,90,28)
        btn_rects[f"mode_{key}"]=draw_btn(r,label,col,active,
            hover=pygame.Rect(r).collidepoint(mouse_pos))
        mbx+=96

    pygame.draw.line(screen,C["panel_border"],(x+16,y+112),(x+w-16,y+112),1)

    # ── BARS ───────────────────────────────
    def bar(label,val,color,row):
        by2=y+122+row*34
        txt(label,(x+20,by2),F["xs"],C["muted"])
        bx2,bw2,bh2=x+20+155,175,11
        pygame.draw.rect(screen,(210,220,235),(bx2,by2,bw2,bh2),border_radius=6)
        fw=int(bw2*max(0,min(1,val)))
        if fw>0: pygame.draw.rect(screen,color,(bx2,by2,fw,bh2),border_radius=6)
        pygame.draw.rect(screen,C["panel_border"],(bx2,by2,bw2,bh2),1,border_radius=6)
        txt(f"{val:.2f}",(bx2+bw2+10,by2-1),F["xs"],C["text"])

    fluidity=max(0.0,1.0-blocked/6.0)
    bar("YOLO Confidence:", CONF, C["blue"], 0)
    bar("Decision Threshold:", THRESHOLD, C["amber"], 1)
    bar("Traffic Fluidity:", fluidity, C["green"], 2)
    bar("Emergency Delay:", min(1,ev_wait/15), C["red"], 3)
    spd_norm=min(1,((EV_PRIO if priority else (EV_PRIO*0.85 if baseline_released else EV_SPD)))/EV_PRIO)
    bar("EV Speed (norm.):", spd_norm, C["ev_blue"], 4)

    pygame.draw.line(screen,C["panel_border"],(x+16,y+300),(x+w-16,y+300),1)

    # ── STATUS ─────────────────────────────
    draw_shield(x+20,y+310,priority)
    sx2,sy2=x+112,y+310
    txt("STATUS",(sx2,sy2),F["xs"],C["muted"])
    if MODE=="baseline":
        if baseline_released:
            s_txt, s_col = "STANDARD GREEN", C["green"]
            desc = "Cycle normal: ambulance released"
        else:
            s_txt, s_col = "NO PRIORITY", C["muted"]
            desc = "Ambulance obeys normal red light"
    elif MODE=="auto":
        s_txt = "GLOBAL PREEMPTION" if priority else "WAITING DETECTION"
        s_col = C["green"] if priority else C["blue"]
        desc = "Auto priority as soon as EV enters zone"
    else:
        if priority:
            s_txt, s_col = "AI DECISION ACCEPTED", C["green"]
            desc = f"conf({CONF:.2f}) >= thresh({THRESHOLD:.2f})"
        else:
            s_txt, s_col = "AI DECISION REJECTED", C["red"] if CONF<THRESHOLD else C["amber"]
            desc = f"conf({CONF:.2f}) < thresh({THRESHOLD:.2f})"

    txt(s_txt,(sx2,sy2+18),F["lg"],s_col,shadow=True)
    txt(desc,(sx2,sy2+42),F["xs"],C["muted"])
    txt(f"Current Wait: {ev_wait:.1f}s",(sx2,sy2+62),F["xs"],C["red"])

    pygame.draw.line(screen,C["panel_border"],(x+16,y+400),(x+w-16,y+400),1)

    # ── THRESHOLD BUTTONS ──────────────────
    txt("THRESHOLD",(x+20,y+408),F["xs"],C["muted"])
    tbx=x+20
    for val,label in [(0.60,"0.60"),(0.70,"0.70"),(0.80,"0.80")]:
        active=abs(THRESHOLD-val)<0.01
        r=(tbx,y+422,82,26)
        btn_rects[f"thresh_{val}"]=draw_btn(r,label,C["amber"],active,
            hover=pygame.Rect(r).collidepoint(mouse_pos))
        tbx+=88

    # ── CONF SCORE BUTTON ──────────────────
    txt("YOLO SCORE",(x+20,y+458),F["xs"],C["muted"])
    col_conf=C["blue"] if CONF>=THRESHOLD else C["red"]
    r=(x+20,y+472,130,26)
    btn_rects["conf"]=draw_btn(r,f"Score: {CONF:.2f}",col_conf,False,
        hover=pygame.Rect(r).collidepoint(mouse_pos))

    # ── STOP / PLAY + RESET ────────────────
    pygame.draw.line(screen,C["panel_border"],(x+16,y+508),(x+w-16,y+508),1) if y+508<y+h else None

    stop_col=C["red"] if paused else C["muted"]
    play_col=C["green"] if not paused else C["muted"]
    r1=(x+20,y+472,60,26)   # stop/play share row with conf
    # row for stop/play/reset
    r_stop=(x+165,y+472,60,26)
    r_play=(x+232,y+472,60,26)
    r_reset=(x+300,y+472,90,26)
    btn_rects["stop"] =draw_btn(r_stop, "STOP" if not paused else "PAUSED", C["red"],  paused,  hover=pygame.Rect(r_stop).collidepoint(mouse_pos))
    btn_rects["play"] =draw_btn(r_play, "PLAY",   C["green"], not paused, hover=pygame.Rect(r_play).collidepoint(mouse_pos))
    btn_rects["reset"]=draw_btn(r_reset,"RESET",  C["muted"], False,      hover=pygame.Rect(r_reset).collidepoint(mouse_pos))

# ═══════════════════════════════════════════
#  DRAW — COMPARISON PANEL (right side)
# ═══════════════════════════════════════════
def draw_comparison():
    x,y,w,h=WIDTH-310,18,295,310
    alpha_rect(screen,C["panel"],(x,y,w,h),radius=14,alpha=228)
    pygame.draw.rect(screen,C["panel_border"],(x,y,w,h),2,border_radius=14)
    txt("MODE COMPARISON",(x+w//2,y+16),F["lg"],C["text"],center=True)
    pygame.draw.line(screen,C["panel_border"],(x+14,y+40),(x+w-14,y+40),1)

    modes=[
        ("baseline","BASELINE",C["muted"]),
        ("auto",    "AUTO",    C["blue"]),
        ("confidence","CONF",  C["green"]),
    ]
    col_labels=["EV Wait","EV Travel","Blocked"]
    # header
    hx=x+16
    for i,lbl in enumerate(col_labels):
        txt(lbl,(hx+90+i*62,y+50),F["xs"],C["muted"],center=True)

    for ri,(key,label,col) in enumerate(modes):
        ry=y+68+ri*72
        # Row bg
        row_alpha=200 if MODE==key else 140
        alpha_rect(screen,(230,238,252),(x+10,ry,w-20,62),radius=8,alpha=row_alpha)
        if MODE==key:
            pygame.draw.rect(screen,col,(x+10,ry,w-20,62),2,border_radius=8)

        # Mode label
        pygame.draw.circle(screen,col,(x+24,ry+18),7)
        txt(label,(x+36,ry+10),F["sm"],col)

        s=stats[key]
        runs=max(1,s["runs"])
        avg_wait=s["ev_wait_total"]/runs
        avg_travel=s["ev_travel_total"]/runs
        avg_blocked=s["blocked_total"]/runs

        # Mini bars
        metrics=[(avg_wait,15,C["red"]),(avg_travel,60,C["blue"]),(avg_blocked,6,C["amber"])]
        for i,(val,mx,bc) in enumerate(metrics):
            bx2=x+90+i*62; by2=ry+36; bw2=52; bh2=8
            pygame.draw.rect(screen,(210,220,235),(bx2,by2,bw2,bh2),border_radius=4)
            fw=int(bw2*min(1,val/mx)) if mx>0 else 0
            if fw>0: pygame.draw.rect(screen,bc,(bx2,by2,fw,bh2),border_radius=4)
            # Value text
            v_str=f"{val:.1f}s" if i<2 else f"{val:.1f}"
            txt(v_str,(bx2+bw2//2,by2-12),F["xs"],bc,center=True)

        # Current run live values
        if MODE==key:
            live=f"NOW: wait={ev_wait:.1f}s  blk={blocked}"
            txt(live,(x+16,ry+46),F["xs"],col)

    # Legend note
    pygame.draw.line(screen,C["panel_border"],(x+14,y+286),(x+w-14,y+286),1)
    txt("Avg over completed runs",(x+w//2,y+298),F["xs"],C["muted"],center=True)

# ═══════════════════════════════════════════
#  DRAW — LEGEND + METRICS
# ═══════════════════════════════════════════
def draw_legend():
    x,y,w,h=WIDTH-310,340,295,185
    alpha_rect(screen,C["panel"],(x,y,w,h),radius=14,alpha=228)
    pygame.draw.rect(screen,C["panel_border"],(x,y,w,h),2,border_radius=14)
    txt("LEGEND",(x+20,y+14),F["lg"],C["text"])
    pygame.draw.line(screen,C["panel_border"],(x+14,y+42),(x+w-14,y+42),1)
    items=[
        ("Bounding Box",None,C["blue"],True),
        ("Green Light",C["green"],None,False),
        ("Red Light",C["red"],None,False),
        ("YOLO Zone",C["orange"],None,False),
        ("EV Ambulance",C["ev_red"],None,False),
    ]
    for i,(label,dot_col,border_col,is_box) in enumerate(items):
        iy=y+54+i*25
        if is_box: pygame.draw.rect(screen,border_col,(x+18,iy+2,18,14),2,border_radius=3)
        else: glow(x+27,iy+9,12,dot_col,60); pygame.draw.circle(screen,dot_col,(x+27,iy+9),7)
        txt(label,(x+48,iy),F["xs"],C["text"])

def draw_metrics():
    bw,bh=560,56; bx=WIDTH//2-bw//2; by=HEIGHT-bh-14
    alpha_rect(screen,C["panel"],(bx,by,bw,bh),radius=30,alpha=225)
    pygame.draw.rect(screen,C["panel_border"],(bx,by,bw,bh),2,border_radius=30)
    mode_label={"baseline":"BASELINE","auto":"AUTO","confidence":"CONF"}[MODE]
    mode_col={"baseline":C["muted"],"auto":C["blue"],"confidence":C["green"]}[MODE]
    metrics=[
        (f"{int(ev_travel)}s","EV Travel",C["blue"]),
        (f"{ev_wait:.1f}s","EV Wait",C["red"]),
        (f"{blocked}","Blocked",C["amber"]),
        ("PAUSED" if paused else "LIVE","Status",C["red"] if paused else C["green"]),
        (mode_label,"Mode",mode_col),
    ]
    col_w=bw//len(metrics)
    for i,(val,label,col) in enumerate(metrics):
        cx2=bx+i*col_w+col_w//2
        if i>0: pygame.draw.line(screen,C["panel_border"],(bx+i*col_w,by+12),(bx+i*col_w,by+bh-12),1)
        txt(val,(cx2,by+8),F["lg"],col,center=True,shadow=True)
        txt(label,(cx2,by+36),F["xs"],C["muted"],center=True)

def draw_notification():
    if notification_timer<=0: return
    alpha=min(255,notification_timer*8)
    if MODE=="baseline":
        msg="⚡  BASELINE MODE — No EV priority"
        col=C["muted"]
    elif priority:
        msg="🚨  PRIORITY GRANTED — Green corridor active"
        col=C["green"]
    else:
        msg="✅  Intersection cleared — Normal traffic"
        col=C["amber"]
    bw,bh=540,38; bx=WIDTH//2-bw//2; by=76
    alpha_rect(screen,col,(bx,by,bw,bh),radius=20,alpha=int(alpha*0.88))
    txt(msg,(bx+bw//2,by+bh//2),F["md"],(255,255,255),center=True,shadow=True)

def draw_pause_overlay():
    if not paused: return
    s=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA)
    s.fill((10,16,28,90)); screen.blit(s,(0,0))
    bw,bh=320,80; bx=WIDTH//2-bw//2; by=HEIGHT//2-bh//2
    alpha_rect(screen,C["panel"],(bx,by,bw,bh),radius=18,alpha=240)
    pygame.draw.rect(screen,C["red"],(bx,by,bw,bh),2,border_radius=18)
    txt("⏸  SIMULATION PAUSED",(WIDTH//2,HEIGHT//2-10),F["lg"],C["red"],center=True)
    txt("Press PLAY or SPACE to resume",(WIDTH//2,HEIGHT//2+18),F["xs"],C["muted"],center=True)

# ═══════════════════════════════════════════
#  UPDATE
# ═══════════════════════════════════════════
def clamp_gap(car_list,direction=1):
    sorted_cars=sorted(car_list,key=lambda c:c["t"]*direction,reverse=True)
    for i in range(1,len(sorted_cars)):
        leader=sorted_cars[i-1]; follower=sorted_cars[i]
        gap=(leader["t"]-follower["t"])*direction
        if gap<MIN_GAP:
            sorted_cars[i]["t"]=leader["t"]-MIN_GAP*direction

def compute_priority():
    """Return True if EV should get priority based on current mode."""
    det_t=DET_WY/(RH*2.1)
    clear_t=CLEAR_WY/(RH*2.1)
    in_range=clear_t<ev_t<det_t+0.20
    if MODE=="baseline":   return False
    elif MODE=="auto":     return in_range
    else:                  return in_range and (CONF>=THRESHOLD)

def update():
    global ev_t, priority, ev_wait, ev_travel, frame
    global notification_timer, prev_priority, baseline_released
    global ev_detected_logged, priority_logged, crossed_logged, event_log
    global light_transition_timer, last_run_summary, kpi_timer

    if paused:
        return

    frame += 1
    stop_t = STOP_WY / (RH * 2.1)
    det_t = DET_WY / (RH * 2.1)
    clear_t = CLEAR_WY / (RH * 2.1)
    sim_time = int(frame / 60)

    if kpi_timer > 0:
        kpi_timer -= 1

    if (not ev_detected_logged) and ev_t < det_t + 0.20:
        ev_detected_logged = True
        event_log.append((sim_time, "EV detected in YOLO zone", C["blue"]))

    priority = compute_priority()

    if priority and not priority_logged:
        priority_logged = True
        event_log.append((sim_time, f"Priority granted ({MODE})", C["green"]))

    if priority != prev_priority:
        notification_timer = 90
        light_transition_timer = 35
    prev_priority = priority

    if notification_timer > 0:
        notification_timer -= 1
    if light_transition_timer > 0:
        light_transition_timer -= 1

    # BASELINE: the ambulance behaves like a normal vehicle.
    # It stops before the red light, then it is released by a normal light cycle.
    if MODE == "baseline" and not baseline_released:
        next_ev_t = ev_t - EV_SPD / (RH * 2.1)
        if next_ev_t <= stop_t:
            ev_t = stop_t
            ev_wait += 1 / 60.0
            if ev_wait >= BASELINE_RELEASE_AFTER:
                baseline_released = True
                light_transition_timer = 35
                event_log.append((sim_time, "Normal light cycle releases EV", C["amber"]))
        else:
            ev_t = next_ev_t
    else:
        if priority:
            spd = EV_PRIO
        elif baseline_released:
            spd = EV_PRIO * 0.85
        else:
            spd = EV_SPD
        ev_t -= spd / (RH * 2.1)

    if frame > 60:
        ev_travel = max(0, int((1.6 - ev_t) * RH * 2.1 / 60))

    if (not crossed_logged) and ev_t < clear_t:
        crossed_logged = True
        event_log.append((sim_time, "EV cleared the intersection", C["green"]))

    if ev_t < -1.5:
        s = stats[MODE]
        s["ev_wait_total"] += ev_wait
        s["ev_travel_total"] += ev_travel
        s["blocked_total"] += blocked
        s["runs"] += 1
        last_run_summary = {"mode": MODE, "wait": ev_wait, "travel": ev_travel, "blocked": blocked}
        kpi_timer = 240
        ev_t = 1.6
        priority = False
        ev_wait = 0.0
        ev_travel = 0
        baseline_released = False
        ev_detected_logged = False
        priority_logged = False
        crossed_logged = False
        event_log = []

    # Cars: close vehicles stop, farther vehicles slow down.
    STOP0 = -0.14
    STOP1 = 0.14
    STOP2 = -0.14
    for car in cars:
        lane = car["lane"]
        must_stop = False
        slow_down = False

        if priority:
            if lane == 0 and STOP0 - 0.35 < car["t"] <= STOP0 + 0.30:
                must_stop = True
                if car["t"] > STOP0:
                    car["t"] = STOP0
            elif lane == 1 and STOP1 - 0.30 <= car["t"] < STOP1 + 0.35:
                must_stop = True
                if car["t"] < STOP1:
                    car["t"] = STOP1
            elif lane == 2 and STOP2 - 0.35 < car["t"] <= STOP2 + 0.20:
                must_stop = True
                if car["t"] > STOP2:
                    car["t"] = STOP2
            elif lane == 0 and STOP0 - 0.75 < car["t"] <= STOP0 + 0.70:
                slow_down = True
            elif lane == 1 and STOP1 - 0.70 <= car["t"] < STOP1 + 0.75:
                slow_down = True
            elif lane == 2 and STOP2 - 0.75 < car["t"] <= STOP2 + 0.55:
                slow_down = True

        car["is_blocked"] = must_stop

        if not must_stop:
            speed_factor = 0.30 if slow_down else 1.0
            car["t"] += speed_factor * car["spd"] / (RH * 2.2)

        if car["t"] > 1.55:
            car["t"] = -1.55
        if car["t"] < -1.55:
            car["t"] = 1.55

    lane0 = [c for c in cars if c["lane"] == 0]
    lane1 = [c for c in cars if c["lane"] == 1]
    lane2 = [c for c in cars if c["lane"] == 2]
    clamp_gap(lane0, +1)
    clamp_gap(lane1, -1)
    clamp_gap(lane2, +1)




# ═══════════════════════════════════════════
#  DRAW — TIMELINE
# ═══════════════════════════════════════════
def draw_timeline():
    x, y, w, h = 455, HEIGHT - 95, 590, 42
    alpha_rect(screen, C["panel"], (x, y, w, h), radius=18, alpha=225)
    pygame.draw.rect(screen, C["panel_border"], (x, y, w, h), 2, border_radius=18)

    if MODE == "baseline":
        events = [
            ("Detection inactive", C["muted"]),
            ("No priority", C["red"]),
            ("EV waits" if not baseline_released else "Released", C["amber"] if not baseline_released else C["green"]),
        ]
    elif MODE == "auto":
        events = [
            ("EV detected", C["blue"]),
            ("Priority granted" if priority else "Waiting zone", C["green"] if priority else C["amber"]),
            ("Green corridor" if priority else "Normal", C["green"] if priority else C["muted"]),
        ]
    else:
        if CONF >= THRESHOLD:
            events = [
                ("YOLO detected", C["blue"]),
                ("Confidence accepted", C["green"]),
                ("Priority granted" if priority else "Waiting zone", C["green"] if priority else C["amber"]),
            ]
        else:
            events = [
                ("YOLO detected", C["blue"]),
                ("Confidence rejected", C["red"]),
                ("No priority", C["amber"]),
            ]

    step_w = w // len(events)
    for i, (label, col) in enumerate(events):
        cx = x + step_w * i + step_w // 2
        cy = y + 18
        if i > 0:
            pygame.draw.line(screen, C["panel_border"], (x + step_w*i, y+14), (x + step_w*i, y+h-14), 1)
        pygame.draw.circle(screen, col, (cx, cy), 6)
        txt(label, (cx, y+29), F["xs"], col, center=True)

# ═══════════════════════════════════════════
#  DRAW — KPI FINAL SUMMARY
# ═══════════════════════════════════════════
def draw_kpi_popup():
    if not last_run_summary or kpi_timer <= 0:
        return

    x, y, w, h = WIDTH//2 - 250, 118, 500, 145
    alpha_rect(screen, C["panel"], (x, y, w, h), radius=18, alpha=238)
    pygame.draw.rect(screen, C["green"], (x, y, w, h), 2, border_radius=18)
    txt("RUN SUMMARY — KPI", (x+w//2, y+18), F["lg"], C["text"], center=True, shadow=True)
    pygame.draw.line(screen, C["panel_border"], (x+22, y+42), (x+w-22, y+42), 1)

    mode_col = {"baseline": C["muted"], "auto": C["blue"], "confidence": C["green"]}.get(last_run_summary["mode"], C["text"])
    txt(f"Mode: {last_run_summary['mode'].upper()}", (x+35, y+58), F["sm"], mode_col)
    txt(f"EV travel time: {last_run_summary['travel']} s", (x+35, y+82), F["sm"], C["blue"])
    txt(f"EV waiting time: {last_run_summary['wait']:.1f} s", (x+260, y+82), F["sm"], C["red"])
    txt(f"Blocked vehicles: {last_run_summary['blocked']}", (x+35, y+106), F["sm"], C["amber"])
    txt("This summary is stored in the comparison panel averages.", (x+w//2, y+130), F["xs"], C["muted"], center=True)

# ═══════════════════════════════════════════
#  CLICK HANDLER
# ═══════════════════════════════════════════
def handle_click(pos):
    global MODE, THRESHOLD, CONF, conf_idx, paused
    for key,rect in btn_rects.items():
        if pygame.Rect(rect).collidepoint(pos):
            if key=="mode_baseline": MODE="baseline"; reset()
            elif key=="mode_auto":   MODE="auto";     reset()
            elif key=="mode_confidence": MODE="confidence"; reset()
            elif key=="thresh_0.6":  THRESHOLD=0.60
            elif key=="thresh_0.7":  THRESHOLD=0.70
            elif key=="thresh_0.8":  THRESHOLD=0.80
            elif key=="conf":
                conf_idx=(conf_idx+1)%len(CONF_VALS); CONF=CONF_VALS[conf_idx]
            elif key=="stop":  paused=True
            elif key=="play":  paused=False
            elif key=="reset": reset()

# ═══════════════════════════════════════════
#  MAIN LOOP
# ═══════════════════════════════════════════
running=True
while running:
    mouse_pos=pygame.mouse.get_pos()

    for event in pygame.event.get():
        if event.type==pygame.QUIT: running=False
        if event.type==pygame.KEYDOWN:
            if   event.key==pygame.K_1: THRESHOLD=0.60
            elif event.key==pygame.K_2: THRESHOLD=0.70
            elif event.key==pygame.K_3: THRESHOLD=0.80
            elif event.key==pygame.K_b: MODE="baseline"; reset()
            elif event.key==pygame.K_a: MODE="auto";     reset()
            elif event.key==pygame.K_c: MODE="confidence"; conf_idx=(conf_idx+1)%len(CONF_VALS); CONF=CONF_VALS[conf_idx]
            elif event.key==pygame.K_SPACE: paused=not paused
            elif event.key==pygame.K_r: reset()
            elif event.key==pygame.K_ESCAPE: running=False
        if event.type==pygame.MOUSEBUTTONDOWN and event.button==1:
            handle_click(event.pos)

    update()
    draw_bg()
    draw_environment()
    draw_roads()
    draw_heatmap()
    draw_yolo_zone()
    draw_lights()
    draw_ev_path()
    draw_green_corridor()
    draw_radar_scan()
    draw_scene()
    draw_dashboard()
    draw_comparison()
    draw_legend()
    draw_timeline()
    draw_metrics()
    draw_notification()
    draw_kpi_popup()
    draw_pause_overlay()
    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()