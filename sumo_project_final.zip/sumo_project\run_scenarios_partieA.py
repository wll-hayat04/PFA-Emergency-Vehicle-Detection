import os
import csv
import random
import traci

# =============================================================
# CONFIGURATION
# =============================================================
SUMO_HOME = r"C:\Program Files (x86)\Eclipse\Sumo"
os.environ["SUMO_HOME"] = SUMO_HOME

SUMO_BINARY = rf"{SUMO_HOME}\bin\sumo.exe"   # sans GUI pour aller plus vite
SUMO_CFG    = r"C:\Users\user\Desktop\sumo_project\simulation_intersection.sumocfg"
NET_FILE    = r"C:\Users\user\Desktop\sumo_project\network_intersection.net.xml"

# Route FIXE de l'ambulance (south -> intersection -> north)
# Adapte ces aretes si besoin en regardant ton reseau dans SUMO-GUI
AMBULANCE_ROUTE = [
    "south_entry",
    "south_to_center",
    "center_to_north",
    "north_exit"
]

AMBULANCE_ID          = "ambulance0"
AMBULANCE_DEPART_STEP = 10
SIMULATION_END        = 300    # 300 steps = 300 secondes

# Niveaux de trafic : nom -> fichier routes
TRAFFIC_LEVELS = {
    "faible" : r"C:\Users\user\Desktop\sumo_project\routes_faible.rou.xml",
    "moyen"  : r"C:\Users\user\Desktop\sumo_project\routes_moyen.rou.xml",
    "dense"  : r"C:\Users\user\Desktop\sumo_project\routes_dense.rou.xml",
}

# 3 repetitions par scenario (seeds differents)
SEEDS = [42, 123, 456]

# Scenarios : 3 modes du sujet PFA
SCENARIOS = [
    {"mode": "baseline",   "threshold": 0.0,  "label": "Baseline"},
    {"mode": "auto",       "threshold": 0.0,  "label": "Auto (priorite totale)"},
    {"mode": "confidence", "threshold": 0.60, "label": "Confidence θ=0.60"},
    {"mode": "confidence", "threshold": 0.70, "label": "Confidence θ=0.70"},
    {"mode": "confidence", "threshold": 0.80, "label": "Confidence θ=0.80"},
]

# Score YOLO fixe (issu de l'analyse du modele entraine)
YOLO_CONFIDENCE = 0.71

# =============================================================
# UTILITAIRES
# =============================================================
def get_ambulance_link_indices(tls_id, amb_edge, next_edge):
    """Trouve les indices des liens du feu correspondant au trajet EV."""
    controlled = traci.trafficlight.getControlledLinks(tls_id)
    indices = []
    for i, phase_links in enumerate(controlled):
        for link in phase_links:
            if not link:
                continue
            try:
                from_edge = traci.lane.getEdgeID(link[0])
                to_edge   = traci.lane.getEdgeID(link[1])
            except Exception:
                continue
            if from_edge == amb_edge and (next_edge is None or to_edge == next_edge):
                indices.append(i)
    return indices


def force_green_for_ev(tls_id, amb_indices):
    """Force le lien EV au vert, met les autres au rouge."""
    state     = list(traci.trafficlight.getRedYellowGreenState(tls_id))
    new_state = []
    for idx, sig in enumerate(state):
        if idx in amb_indices:
            new_state.append("G")
        elif sig in ("g", "G"):
            new_state.append("r")
        else:
            new_state.append(sig)
    traci.trafficlight.setRedYellowGreenState(tls_id, "".join(new_state))


# =============================================================
# SIMULATION
# =============================================================
def run_simulation(mode, threshold, traffic_level, seed):
    """
    Lance une simulation SUMO avec le mode et niveau de trafic donnes.
    Retourne un dict de KPIs.
    """
    rng = random.Random(seed)

    # Modifier le fichier de routes dans la config
    route_file = TRAFFIC_LEVELS[traffic_level]

    sumo_cmd = [
        SUMO_BINARY,
        "-c", SUMO_CFG,
        "--route-files", route_file,
        "--seed", str(seed),
        "--no-warnings",
        "--no-step-log",
    ]

    traci.start(sumo_cmd)

    tls_ids = traci.trafficlight.getIDList()

    # Sauvegarder les programmes originaux des feux
    original_programs = {}
    for tls_id in tls_ids:
        original_programs[tls_id] = traci.trafficlight.getProgram(tls_id)

    step                 = 0
    ambulance_added      = False
    ev_travel_start      = None
    ev_travel_end        = None
    ev_waiting_time      = 0.0
    normal_wait_sum      = 0.0
    normal_vehicle_count = 0
    queue_sum            = 0.0
    steps_count          = 0
    tls_forced           = set()

    while step < SIMULATION_END:
        traci.simulationStep()
        vehicles = traci.vehicle.getIDList()

        # ── Ajout de l'ambulance a t=10 ──────────────────────
        if step == AMBULANCE_DEPART_STEP and not ambulance_added:
            try:
                traci.route.add("ambulance_route", AMBULANCE_ROUTE)
                traci.vehicle.add(
                    vehID   = AMBULANCE_ID,
                    routeID = "ambulance_route",
                    depart  = "now",
                    typeID  = "DEFAULT_VEHTYPE"
                )
                traci.vehicle.setColor(AMBULANCE_ID, (255, 0, 0, 255))
                traci.vehicle.setMaxSpeed(AMBULANCE_ID, 25.0)
                ambulance_added  = True
                ev_travel_start  = step
            except Exception as e:
                print(f"  [WARN] Ambulance non ajoutee : {e}")

        vehicles = traci.vehicle.getIDList()

        # ── Gestion de la priorite ────────────────────────────
        if AMBULANCE_ID in vehicles:
            ev_waiting_time = traci.vehicle.getAccumulatedWaitingTime(AMBULANCE_ID)
            route_index     = traci.vehicle.getRouteIndex(AMBULANCE_ID)
            route           = traci.vehicle.getRoute(AMBULANCE_ID)
            route_len       = len(route)

            # Detection arrivee
            if route_len > 0 and route_index >= route_len - 1 and ev_travel_end is None:
                ev_travel_end = step

            amb_edge  = traci.vehicle.getRoadID(AMBULANCE_ID)
            next_edge = route[route_index + 1] if route_index + 1 < route_len else None

            # Calcul de la decision de priorite
            if mode == "auto":
                priority_active = True
            elif mode == "confidence":
                priority_active = (YOLO_CONFIDENCE >= threshold)
            else:  # baseline
                priority_active = False

            # Application sur les feux
            for tls_id in tls_ids:
                amb_indices = get_ambulance_link_indices(tls_id, amb_edge, next_edge)

                if amb_indices and priority_active:
                    force_green_for_ev(tls_id, amb_indices)
                    tls_forced.add(tls_id)
                elif tls_id in tls_forced and not amb_indices:
                    # EV a passe ce feu : restaurer le cycle normal
                    traci.trafficlight.setProgram(tls_id, original_programs[tls_id])
                    tls_forced.discard(tls_id)

        else:
            # EV sorti du reseau : restaurer tous les feux
            if ambulance_added and ev_travel_end is None and step > AMBULANCE_DEPART_STEP:
                ev_travel_end = step
            for tls_id in list(tls_forced):
                traci.trafficlight.setProgram(tls_id, original_programs[tls_id])
                tls_forced.discard(tls_id)

        # ── Metriques trafic civil ────────────────────────────
        queue_count = 0
        for veh in vehicles:
            if veh == AMBULANCE_ID:
                continue
            normal_wait_sum      += traci.vehicle.getAccumulatedWaitingTime(veh)
            normal_vehicle_count += 1
            if traci.vehicle.getSpeed(veh) < 0.1:
                queue_count += 1

        queue_sum   += queue_count
        steps_count += 1
        step        += 1

    traci.close(wait=False)

    # ── Calcul des KPIs finaux ────────────────────────────────
    ev_travel_time = (
        (ev_travel_end - ev_travel_start)
        if ev_travel_start is not None and ev_travel_end is not None
        else None
    )
    avg_delay = round(normal_wait_sum / normal_vehicle_count, 2) if normal_vehicle_count > 0 else 0.0
    avg_queue = round(queue_sum / steps_count, 2)                if steps_count > 0          else 0.0

    return {
        "mode"           : mode,
        "threshold"      : threshold,
        "traffic_level"  : traffic_level,
        "seed"           : seed,
        "ev_travel_time" : ev_travel_time,
        "ev_waiting_time": round(ev_waiting_time, 2),
        "avg_civil_delay": avg_delay,
        "avg_queue_length": avg_queue,
    }


# =============================================================
# BOUCLE PRINCIPALE
# =============================================================
if __name__ == "__main__":

    all_results = []
    total = len(SCENARIOS) * len(TRAFFIC_LEVELS) * len(SEEDS)
    counter = 0

    print(f"\n{'='*60}")
    print(f"  PFA - Partie A : Comparaison 3 modes - 1 intersection")
    print(f"  {len(SCENARIOS)} scenarios x {len(TRAFFIC_LEVELS)} trafics x {len(SEEDS)} seeds = {total} simulations")
    print(f"{'='*60}\n")

    for traffic in TRAFFIC_LEVELS:
        for scenario in SCENARIOS:
            mode      = scenario["mode"]
            threshold = scenario["threshold"]
            label     = scenario["label"]

            ev_times  = []
            ev_waits  = []
            civil_del = []
            queues    = []

            for seed in SEEDS:
                counter += 1
                print(f"[{counter:02d}/{total}] trafic={traffic:6s} | {label:25s} | seed={seed}")

                result = run_simulation(mode, threshold, traffic, seed)
                all_results.append(result)

                if result["ev_travel_time"] is not None:
                    ev_times.append(result["ev_travel_time"])
                ev_waits.append(result["ev_waiting_time"])
                civil_del.append(result["avg_civil_delay"])
                queues.append(result["avg_queue_length"])

            # Affichage resume par scenario
            def fmt(lst):
                if not lst:
                    return "N/A"
                m = sum(lst) / len(lst)
                s = (sum((x - m)**2 for x in lst) / len(lst)) ** 0.5
                return f"{m:.1f} ± {s:.1f}"

            print(f"   EV time  : {fmt(ev_times)} steps")
            print(f"   EV wait  : {fmt(ev_waits)} s")
            print(f"   Civil    : {fmt(civil_del)} s")
            print(f"   Queue    : {fmt(queues)} veh\n")

    # ── Export CSV global ─────────────────────────────────────
    out_csv = "partieA_results.csv"
    with open(out_csv, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=all_results[0].keys())
        writer.writeheader()
        writer.writerows(all_results)

    print(f"\n{'='*60}")
    print(f"  Termine ! {len(all_results)} simulations")
    print(f"  CSV exporte : {out_csv}")
    print(f"  Lance ensuite : python generate_figures_partieA.py")
    print(f"{'='*60}\n")
